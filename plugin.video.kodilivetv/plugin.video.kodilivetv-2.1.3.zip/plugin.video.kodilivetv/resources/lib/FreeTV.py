# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin
import base64 
import urllib2,urllib,cgi, re

try:
    import json
except:
    import simplejson as json

def getUrl(url, cookieJar=None,post=None, timeout=20, headers=None,jsonpost=False):

    cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
    if headers:
        for h,hv in headers:
            req.add_header(h,hv)
    if jsonpost:
        req.add_header('Content-Type', 'application/json')
    response = opener.open(req,post,timeout=timeout)
    if response.info().get('Content-Encoding') == 'gzip':
            from StringIO import StringIO
            import gzip
            buf = StringIO( response.read())
            f = gzip.GzipFile(fileobj=buf)
            link = f.read()
    else:
        link=response.read()
    response.close()
    return link;

def PlaySafeLink(url,name):
    
    import websocket
    ws = websocket.WebSocket()
    
    header=["Origin: http://customer.safersurf.com","User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36"]
    ws.connect("ws://52.48.86.135:1337/tb/m3u8/master/siteid/customer.onlinetv",header=header)
    jsdata=''
    ws.send(jsdata)
    result = ws.recv()   

    jsdata='[{"key":"type","value":"channelrequest"},{"key":"dbid","value":"%s"},{"key":"tbid","value":""},{"key":"format","value":"masterm3u8"},{"key":"proxify","value":"true"},{"key":"bitrate","value":"2290000"},{"key":"maxbitrate","value":"4240000"}]'%url
    ws.send(jsdata)
    result = ws.recv()
    #print repr(result)
    #ws.close()
    headers = [('Referer', 'http://customer.safersurf.com/onlinetv.html'),('User-Agent','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'),('Origin','http://customer.safersurf.com')]
    url=re.findall('[\'"](http.*?)[\'"]',result)[0]
    result=getUrl(url,headers=headers)
    urlToPlay=re.findall('(http.*?)\s',result)[-1]
    import random
    listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ) )
    listitem.setProperty('IsPlayable', 'false')
    if name.find("HD")>-1:
        urlToPlay = urlToPlay.replace("/3305000/","/4240000/")
        urlToPlay = urlToPlay.replace("/2290000/","/4240000/")
        urlToPlay = urlToPlay.replace("/1368000/","/4240000/")
    else:
        urlToPlay = urlToPlay.replace("/3305000/","/2290000/")
        urlToPlay = urlToPlay.replace("/1368000/","/2290000/")
        
    if name.find("Cielo")>-1:
        urlToPlay = urlToPlay.replace("/3003/","/3041/")
    elif name.find("TV 8")>-1:    
        urlToPlay = urlToPlay.replace("/3004/","/3009/")

    elif name.find("Arte HD FR")>-1:
        urlToPlay = urlToPlay.replace("/2010/","/2029/")
    elif name.find("RTS 1 HD")>-1:
        urlToPlay = urlToPlay.replace("/2008/","/2034/")       
    elif name.find("RTS 2 HD")>-1:
        urlToPlay = urlToPlay.replace("/2008/","/2035/") 
    elif name.find("M6 HD")>-1:
        urlToPlay = urlToPlay.replace("/2010/","/2026/")
    elif name.find("France Ô")>-1:
        urlToPlay = urlToPlay.replace("/2009/","/2015/")        
    elif name.find("Gulli")>-1:
        urlToPlay = urlToPlay.replace("/2009/","/2011/") 

    elif name.find("ZDFneo HD")>-1:
        urlToPlay = urlToPlay.replace("/1008/","/1121/")
    elif name.find("ZDFkultur HD")>-1:
        urlToPlay = urlToPlay.replace("/1008/","/1119/")
    elif name.find("ZDFinfo HD")>-1:
        urlToPlay = urlToPlay.replace("/1009/","/1118/")

    xbmc.Player(  ).play( urlToPlay+'|Origin=http://customer.safersurf.com&User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36&Referer=http://customer.safersurf.com/onlinetv.html', listitem)
    xbmc.sleep(1250)
    xbmc.executebuiltin('Dialog.Close(all, true)')
    xbmc.sleep(1750)
    xbmc.executebuiltin('XBMC.PlayerControl(Play)')
    
def PlayOtherUrl ( url,name ):

    url=base64.b64decode(url)

    if url.startswith('cid:'): url=base64.b64decode('aHR0cDovL2ZlcnJhcmlsYi5qZW10di5jb20vaW5kZXgucGhwLzJfNS9neG1sL3BsYXkvJXM=')%url.replace('cid:','')
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Fetching Streaming Info')
    progress.update( 10, "", "Finding links..", "" )

    direct=False
        
    if "ebound:" in url:
        PlayLiveLink(url.split('ebound:')[1])
        return
    if "ebound2:" in url:
        PlayEboundFromIOS(url.split('ebound2:')[1])
        return
    if "ditto:" in url:
        PlayDittoLive(url.split('ditto:')[1])
        return
    if "Sports365:" in url:
        playSports365(url.split('Sports365:')[1],progress)
        return
    if "CF:" in url:
        PlayCFLive(url.split('CF:')[1])
        return    
    if "uktvnow:" in url:
        PlayUKTVNowChannels(url.split('uktvnow:')[1])
        return
    if "direct:" in url:
        PlayGen(base64.b64encode(url.split('direct:')[1]))
        return    
    if "direct3:" in url:
        PlayGen(base64.b64encode(url.split('direct3:')[1]),True,followredirect=True)
        return    
    if "ipbox:" in url:
        playipbox(url.split('ipbox:')[1])
        return
    if "YP:" in url:
        PlayYP(base64.b64encode(url.split('YP:')[1]))
        return
    if "direct2:" in url:
        PlayGen(base64.b64encode(url.split('direct2:')[1]),True)
        return
    if "ptc:" in url:
        PlayGen(base64.b64encode(url.split('ptc:')[1]+getPTCAuth()+'|User-Agent=AppleCoreMedia/1.0.0.13A452 (iPhone; U; CPU OS 9_0_2 like Mac OS X; en_gb)'))
        return    
    if "pv2:" in url:
        PlayPV2Link(url.split('pv2:')[1])
        return 
    if "safe:" in url:
        PlaySafeLink(url.split('safe:')[1],name)
        return            
    if url in [base64.b64decode('aHR0cDovL2xpdmUuYXJ5bmV3cy50di8='),
            base64.b64decode('aHR0cDovL2xpdmUuYXJ5emluZGFnaS50di8='),
            base64.b64decode('aHR0cDovL2xpdmUuYXJ5cXR2LnR2Lw=='),
            base64.b64decode('aHR0cDovL2xpdmUuYXJ5bXVzaWsudHYv'),
            base64.b64decode('aHR0cDovL2xpdmUuYXJ5ZGlnaXRhbC50di8=')]:
        req = urllib2.Request(url)
        
        req.add_header('User-Agent', base64.b64decode('TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4xOyBXT1c2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzQ3LjAuMjUyNi4xMTEgU2FmYXJpLzUzNy4zNg==')) 
        response = urllib2.urlopen(req)
        link=response.read()
        print link
        paa='(content.jwplatform.com.players.*?.js)'
        ln=re.findall(paa,link)
        if len(ln)>0:
            print ln, 'ln val'
            link=getUrl('http://'+ln[0])

        curlpatth='file[\'"]?: [\'"](.*?)[\'"]'
        
        progress.update( 50, "", "Preparing url..", "" )
        dag_url =re.findall(curlpatth,link)[-1]
        if dag_url.startswith('rtmp'): dag_url+=' timeout=20'
        direct=True
    elif url=='etv':
        req = urllib2.Request(base64.b64decode('aHR0cDovL20ubmV3czE4LmNvbS9saXZlLXR2L2V0di11cmR1'))
        req.add_header('User-Agent', 'Mozilla/5.0(iPad; U; CPU iPhone OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B314 Safari/531.21.10')
        response = urllib2.urlopen(req)
        link=response.read()
        curlpatth='<source src="(.*?)"'
        progress.update( 50, "", "Preparing url..", "" )
        dag_url =re.findall(curlpatth,link)[0]
    elif 'dag1.asx' not in url and 'hdcast.org' not in url and '?securitytype=2' not in url and 'bernardotv.club' not in url and 'imob.dunyanews.tv' not in url:
        if '/play/' in url:
            code=base64.b64decode('MDAwNkRDODUz')+binascii.b2a_hex(os.urandom(2))[:3]
            url+=base64.b64decode('L1VTLzEv')+code
            getUrl(base64.b64decode('aHR0cDovL2ZlcnJhcmlsYi5qZW10di5jb20vaW5kZXgucGhwL3htbC9pbml0aWFsaXplLzA1LTAyLTEzMDEwNy0yNC1QT1AtNjE4LTAwMC8yLjIuMS40Lw==')+code)
        req = urllib2.Request(url)
        req.add_header('User-Agent', base64.b64decode('VmVyaXNtby1CbGFja1VJXygyLjQuNy41LjguMC4zNCk='))   

        response = urllib2.urlopen(req)
        link=response.read()
        curlpatth='<link>(.*?)<\/link>'
        progress.update( 50, "", "Preparing url..", "" )
        dag_url =re.findall(curlpatth,link)
        if '[CDATA' in dag_url:
            dag_url=dag_url.split('CDATA[')[1].split(']')[0]
        if not (dag_url and len(dag_url)>0 ):
            curlpatth='\<ENTRY\>\<REF HREF="(.*?)"'
            dag_url =re.findall(curlpatth,link)[0]
        else:
            dag_url=dag_url[0]
    else:
        if 'hdcast.org' in url or 'bernardotv.club' in url:
            direct=True
        dag_url=url
    if '[CDATA' in dag_url:
        dag_url=dag_url.split('CDATA[')[1].split(']')[0]
    
    if '?securitytype=2' in url:
        opener = urllib2.build_opener(NoRedirection)
        response = opener.open(url)
        dag_url = response.info().getheader('Location')
        if '127.0.0.1' not in dag_url: 
            dag_url='rtmp://quinzelivefs.fplive.net/quinzelive-live live=true timeout=15 playpath=%s'%dag_url.split('/')[-1]
            direct=True 

    if 'dag1.asx' in dag_url:    
        req = urllib2.Request(dag_url)
        req.add_header('User-Agent', base64.b64decode('VmVyaXNtby1CbGFja1VJXygyLjQuNy41LjguMC4zNCk='))   
        response = urllib2.urlopen(req)
        link=response.read()
        dat_pattern='href="([^"]+)"[^"]+$'
        dag_url =re.findall(dat_pattern,link)[0]
   
    if direct:
        final_url=dag_url
    else:
        final_url=get_dag_url(dag_url)

    print 'final_url',final_url            
    if 'token=hw_token' in final_url:
        final_url=final_url.split('?')[0]#
        print 'final_url',final_url   
    if 'token=ec_hls_token' in final_url:
        final_url=final_url.split('?')[0]#
        print 'final_url',final_url

    if base64.b64decode('amFkb29fdG9rZW4=') in final_url or 'elasticbeanstalk' in final_url:
        print 'In Ferari url'
        final_url=get_ferrari_url(final_url,progress)        
    progress.update( 100, "", "Almost done..", "" )
    
    if final_url.startswith('http') and 'User-Agent' not in final_url:
        final_url+='|User-Agent=Verismo-BlackUI_(2.4.7.5.8.0.34)'

    listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ) ) 
    xbmc.Player(  ).play( final_url, listitem)
        
