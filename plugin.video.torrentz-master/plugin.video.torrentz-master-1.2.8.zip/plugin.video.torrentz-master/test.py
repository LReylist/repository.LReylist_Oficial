# coding: utf-8
__author__ = 'Ruben'
data = '''

<!DOCTYPE html>
<html>
<head>
<title>the walking dead s06e09 torrent</title>
<link rel="stylesheet" href="/style.33.css" type="text/css" />
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<!--[if lt IE 9]>
<script src="/ie9.js">i_am_old_ie = true;</script>
<![endif]-->
<script type="text/javascript" src="/tzs.10.js"></script>
<link rel="alternate" type="application/rss+xml" title="the walking dead s06e09" href="/feed?q=the+walking+dead+s06e09" />
<link rel="search" href="/secureopensearch.xml" type="application/opensearchdescription+xml" title="Torrentz Search" />
<meta name="viewport" content="width=820">
</head>
<body>
<div class="top">
<h1><a href="/" title="Search Engine">Torrentz</a></h1>
<ul>
<li><a href="/search" title="Torrentz Search">Search</a></li>
<li><a href="/my" title="Personal Search">myTorrentz</a></li>
<li><a href="/profile" title="My Profile">Profile</a></li>
<li><a href="/help" title="Get Help">Help</a></li>
</ul>
</div>

<form action="/search" method="get" class="search"><fieldset><input type="text" name="q" value="the walking dead s06e09" id="thesearchbox" autocomplete="off" /><input type="submit" value="Search" id="thesearchbutton" /></fieldset></form>
<script type="text/javascript">
$(document).ready(function() {$("#thesearchbox").autocomplete("/suggestions.php");});
</script>

<div class="SimpleAcceptebleTextAds"><h3>the walking dead s06e09</h3><dl><dt><a href="//ads.ad-center.com/offer?prod=7&ref=5052214" rel="nofollow">Full <strong>the walking dead s06e09</strong> Download</a></dt><dd>1448 kb/s</dd></dl><dl><dt><a href="//ads.ad-center.com/offer?prod=7&ref=5052214" rel="nofollow"><strong>the walking dead s06e09</strong> [Verified]</a></dt><dd>1509 kb/s</dd></dl><dl><dt><a href="//ads.ad-center.com/offer?prod=7&ref=5052214" rel="nofollow">Direct <strong>the walking dead s06e09</strong> Download</a></dt><dd>1531 kb/s</dd></dl></div><div class="results"><div>Age: <a href="/search?f=the+walking+dead+s06e09+added%3A1d">1d</a> | <a href="/search?f=the+walking+dead+s06e09+added%3A3d">3d</a> | <a href="/search?f=the+walking+dead+s06e09+added%3A7d">7d</a> | <a href="/search?f=the+walking+dead+s06e09+added%3A1m">1m</a> &nbsp; &nbsp; &nbsp; &nbsp; Quality: <a href="/any?f=the+walking+dead+s06e09">any</a> | <b>good</b> | <a href="/verified?f=the+walking+dead+s06e09">verified</a></div><h2 style="border-bottom: none">50 torrents (0.260s) <a rel="nofollow,bookmark" href="/my?add=c2VhcmNoXl50aGUgd2Fsa2luZyBkZWFkIHMwNmUwOQ%3D%3D&amp;k=a32fcb" title="Save"><img src="/img/star.png" width="16" height="16" alt="Save" style="border: 0" /></a></h2><h3>Order by  <a href="/searchN?f=the+walking+dead+s06e09"> rating </a> |  <a href="/searchA?f=the+walking+dead+s06e09"> date </a> |  <a href="/searchS?f=the+walking+dead+s06e09"> size </a> |  <b> peers </b></h3><dl><dt><a href="/972c194c659722c91abca9b830a81e3030853b8d"><b>The</b> <b>Walking</b> <b>Dead</b> <b>S06E09</b> No Way Out 720p WEBRip H 264 AAC Napisy PL</a> &#187; tv hd</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="pe">Pending</span><span class="u">193</span><span class="d">94</span></dd></dl>
<dl><dt><a href="/073bc17e41e32c673b4625f71a4f67d1b8f0f6de">AgusiQ TorrentS pl <b>The</b> <b>Walking</b> <b>Dead</b> <b>S06E09</b> PL KiT AgusiQ</a> &#187; tv hd</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="pe">Pending</span><span class="u">90</span><span class="d">51</span></dd></dl>
<dl><dt><a href="/14d13240f637094fef151e456ddd5545a840d142"><b>The</b> <b>Walking</b> <b>Dead</b> <b>S06E09</b> No Way Out 1080p WEB DL H 264 AC3 Lektor PL i Napisy PL mkv</a> &#187; tv hd</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="pe">Pending</span><span class="u">96</span><span class="d">35</span></dd></dl>
<dl><dt><a href="/c1d67ba3252c206d4b47550120c569ea4348c449"><b>The</b> <b>Walking</b> <b>Dead</b> <b>S06E09</b> SWESUB 1080p HDTV x264 mp4</a> &#187; tv</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="a"><span title="Thu, 18 Feb 2016 21:05:30">1 hour</span></span><span class="s">696 MB</span> <span class="u">54</span><span class="d">17</span></dd></dl>
<dl><dt><a href="/150886cc6691684118ef6f2a468a893a8f5518f4"><b>The</b> <b>Walking</b> <b>Dead</b> <b>S06E09</b> 720p HDTV x264 SVA eztv mkv</a> &#187; tv hd</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="pe">Pending</span><span class="u">55</span><span class="d">10</span></dd></dl>
<dl><dt><a href="/0d607b6d0ccc51f3745b4363fa8dd7994bb1d3d1"><b>The</b> <b>Walking</b> <b>Dead</b> <b>s06e09</b> WEBDLRip NewStudio TV</a> &#187; tv hd</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="a"><span title="Wed, 17 Feb 2016 20:00:10">yesterday</span></span><span class="s">500 MB</span> <span class="u">14</span><span class="d">4</span></dd></dl>
<dl><dt><a href="/f85ed5d7d170d88872dd2dd1e65f69d5331fb607"><b>The</b> <b>Walking</b> <b>Dead</b> <b>s06e09</b> WEBDL 720p NewStudio TV mkv</a> &#187; tv hd</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="pe">Pending</span><span class="u">6</span><span class="d">3</span></dd></dl>
<dl><dt><a href="/30611b09a0dd32b605e19074300147d96c842077"><b>The</b> <b>Walking</b> <b>Dead</b> <b>S06E09</b> HDTV x264 FLEET</a> &#187; tv hd</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="pe">Pending</span><span class="u">1</span><span class="d">1</span></dd></dl>
<dl><dt><a href="/7ba87558b2c5475cd5e63437b3c86b3db5791a14"><b>The</b> <b>Walking</b> <b>Dead</b> <b>S06E09</b> 720p HDTV x264 SVA</a> &#187; tv hd</dt><dd><span class="v" style="color:#fff;background-color:#A2EB80">1</span><span class="pe">Pending</span><span class="u">0</span><span class="d">2</span></dd></dl>
<dl><dt style="text-align: center; width: 100%">41 results removed in compliance with EUCD / DMCA</dt><dd></dd></dl></div><div class="note"><big><b>Not enough torrents?</b></big><br /> - Check your spelling<br /> - Try less or different keywords<br /> - Try <a href="/any?f=the+walking+dead+s06e09">lower quality torrents</a></div><div style="overflow: auto;width: 100%"><ul class="relatedq"><li><a href="/search?q=the+walking+dead+s06e09"><b>the</b> <b>walking</b> <b>dead</b> <b>s06e09</b></a></li></ul><ul class="relatedq"><li><a href="/search?q=the+walking+dead+s06e09+720p"><b>the</b> <b>walking</b> <b>dead</b> <b>s06e09</b> 720p</a></li></ul></div><div class="recent"><a href="/search?q=macbeth">macbeth</a> 3s, <a href="/search?q=frozen">frozen</a> 1s, <a href="/search?q=salem+s01e06">salem s01e06</a> 3s, <a href="/search?q=deadpool+movie">deadpool movie</a> 2s, <a href="/search?q=cesaroni">cesaroni</a> 2s, <a href="/search?q=xxx+sex+pictures">xxx sex pictures</a> 3s, <a href="/search?q=metal+gear+solid+v">metal gear solid v</a> 0s, <a href="/search?q=2016+hindi+movies">2016 hindi movies</a> 0s, <a href="/search?q=windows+8+ita+applications">windows 8 ita applications</a> 3s, <a href="/search?q=justin+mp3">justin mp3</a> 3s</div>
<script type="text/javascript" src="/show_ads.js"></script>

<script data-cfasync='false' type='text/javascript'>
/*3751*/
(function(s, o, l, v, e, d) {
    if (s[o] == null && s[l + e]) {
        s[o] = "loading";
        s[l + e](d, l = function() {
            s[o] = "complete";
            s[v + e](d, l, !1)
        }, !1)
    }
})(document, "readyState", "add", "remove", "EventListener", "DOMContentLoaded");
(function() {
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.async = true;
    s.src = "//cdn.engine.trklnks.com/Scripts/infinity.js.aspx?guid=94a11f9d-20ab-4e70-a8e0-f4808a235ba6";
    s.id = "infinity";
    s.setAttribute("data-guid", "94a11f9d-20ab-4e70-a8e0-f4808a235ba6");
    s.setAttribute("data-version", "async");
    s.setAttribute("data-abr", "false");
    var e = document.getElementsByTagName("script")[0];
    e.parentNode.insertBefore(s, e)
})();
(function() {
    var calc = function() {
        if (typeof g367CB268B1094004A3689751E7AC568F == "undefined" || !g367CB268B1094004A3689751E7AC568F.Core) {
            var domain = "ticrite.com";
            var file = "ac.aspc";
            var siteGuid = "94a11f9d-20ab-4e70-a8e0-f4808a235ba6".replace(/-/g, "");
            (function() {
                var s = document.createElement("script");
                s.type = "text/javascript";
                s.async = true;
                s.src = "//" + domain + "/" + siteGuid;
                s.id = "infinity";
                s.setAttribute("data-guid", "94a11f9d-20ab-4e70-a8e0-f4808a235ba6");
                s.setAttribute("data-version", "async");
                s.setAttribute("data-abr", "true");
                var e = document.getElementsByTagName("script")[0];
                e.parentNode.insertBefore(s, e)
            })()
        }
    };
    var addEvent = function(element, event, fn) {
        if (element.addEventListener) element.addEventListener(event, fn, false);
        else if (element.attachEvent) element.attachEvent("on" + event, fn)
    };
    addEvent(window, "load", calc)
})();
</script><div class="footer">&copy; 2003-2016 Torrentz<br /><span style="color:#FFF">0.460s</span></div></body></html>
'''
import bs4
soup = bs4.BeautifulSoup(data)
links = soup.select("strong a")
for link in links:
    print link.get("title", ""), link["href"]



# import requests
#
# url = "http://www.elitetorrent.net/categoria/1/estrenos/modo:listado/pag:1"
# browser = requests.Session()
# page = "1"
# import bs4
#
# response = browser.get( url + page)
# soup = bs4.BeautifulSoup(response.text)
# links = soup.select("a.nombre")
# for link in links:
#     print link.get("title", ""), link["href"]

# import re
#
# datos = re.search("var datos =(.*?);", data, re.DOTALL).group(1).replace("{", "").replace("}", "")
# params = {}
# for item in datos.split("\n"):
#     if item.strip() != "":
#         key, value = item.strip()[:-1].split(':')
#         params[key] = value.replace("'", "")
# #settings.debug(params)
# opciones = re.search("var options =(.*?);", data, re.DOTALL).group(1).replace("{", "").replace("}", "") + ": ''"
# params1 = {}
# for item in opciones.split("\n"):
#     if item.strip() != "":
#         key, value = item.strip()[:-1].split(':')
#         params1[key] = value.replace("'", "")
# #settings.debug(params1)
# urlPage = re.search('url: "(.*?)"', data).group(1)
