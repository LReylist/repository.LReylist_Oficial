script.module.oauth2client
=======================

An XBMC addon that wraps up the Google Oauth2Client libraries. 

See the Google documentation for usage. http://google.github.io/oauth2client/
