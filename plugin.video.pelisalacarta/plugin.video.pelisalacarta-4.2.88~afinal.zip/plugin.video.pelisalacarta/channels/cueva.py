# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
# ------------------------------------------------------------

import re
import sys
import urllib
import urlparse

from core import config
from core import httptools
from core import logger
from core import scrapertools
from core import servertools
from core.item import Item
from core import channeltools
from core import tmdb

__channel__ = "cueva"

host = "http://cueva.pro/"

try:
    __modo_grafico__ = config.get_setting('modo_grafico', __channel__)
    __perfil__ = int(config.get_setting('perfil', __channel__))
except:
    __modo_grafico__ = True
    __perfil__ = 0

# Fijar perfil de color

perfil = [['0xFFDDD3F7', '0xFF2E64FE', '0xFF0404B4'],
          ['0xFFA5F6AF', '0xFF5FDA6D', '0xFF11811E'],
          ['0xFF58D3F7', '0xFF2E64FE', '0xFF0404B4']]

if __perfil__ - 1 >= 0:
    color1, color2, color3 = perfil[__perfil__ - 1]
else:
    color1 = color2 = color3 = ""

headers = [['User-Agent', 'Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0'],
           ['Referer', host]]

thumbnail = "https://raw.githubusercontent.com/Inter95/tvguia/master/thumbnails/%s.png"
parameters = channeltools.get_channel_parameters(__channel__)
fanart_host = parameters['fanart']
thumbnail_host = parameters['thumbnail']

# parameters = channeltools.get_channel_parameters('petropolis')
# fanart_host = parameters['fanart']
# thumbnail_host = parameters['thumbnail']
# color1, color2, color3 = ['0xFFA5F6AF', '0xFF5FDA6D', '0xFF11811E']


def mainlist(item):
    logger.info()
    itemlist = []
    item.url = host
    # item.text_color = color1
    # item.fanart = fanart_host
    # thumbnail = "https://raw.githubusercontent.com/master-1970/resources/master/images/genres/4/verdes/%s.png"

    itemlist.append(item.clone(title="Novedades", action="peliculas", page=0, contentType='movie',
                               viewcontent='movies', url=host + 'ver-peliculas-online', viewmode="movie_with_plot",
                               thumbnail=thumbnail % 'novedades'))

    itemlist.append(item.clone(title="Estrenos", action="peliculas", page=0, contentType='movie', extra='estrenos',
                               viewcontent='movies', url=host + 'ver-peliculas-online?ver=estrenos', viewmode="movie_with_plot",
                               thumbnail=thumbnail % 'estrenos'))

    itemlist.append(item.clone(title="Populares", action="peliculas", page=0, contentType='movie',
                               viewcontent='movies', url=host + 'ver-peliculas-online?ver=populares',
                               viewmode="movie_with_plot", thumbnail=thumbnail % 'populares'))

    itemlist.append(item.clone(title="Series", action="series", content_type='tvshow', thumbnail=thumbnail % 'series',
                               viewcontent='movies', page=0, extra='serie', url=host + 'ver-series-online', viewmode="movie_with_plot"))

    itemlist.append(item.clone(title="Buscar", action="search", thumbnail=thumbnail % 'busqueda',
                               url=host))

    return itemlist


def search(item, texto):
    logger.info()

    texto = texto.replace(" ", "+")
    item.url = urlparse.urljoin(item.url, "search/{0}".format(texto))

    try:
        return sub_search(item)

    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("{0}".format(line))
        return []


def sub_search(item):
    logger.info()

    itemlist = []
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|&nbsp;|<br>", "", data)

    patron = '<div class="item"><a href="([^"]+)">.*?'
    patron += 'title="([^"]+)" src="([^"]+)">.*?'
    patron += '<div class="tipo">([^"]+)</div>'
    # patron += 'Ver\s(.*?)\sOnline'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, name, img, tipo in matches:
        if tipo == 'Serie':
            action = 'temporadas'
            url = scrapedurl
        else:
            url = scrapedurl + '?ver=pelicula'
            action = 'get_findvideos'

        itemlist.append(item.clone(title=name, url=url, contentSerieName=name,
                                   action=action, contentTitle=name, plot=item.plot,
                                   thumbnail=img, text_color=color3))

    tmdb.set_infoLabels(itemlist)

    paginacion = scrapertools.find_single_match(
        data, '<a class="page larger" href="([^"]+)">\d+</a>')

    if paginacion:
        itemlist.append(item.clone(channel=__channel__, action="sub_search",
                             title=">> Página Siguiente", url=paginacion,
                             thumbnail='https://raw.githubusercontent.com/Inter95/tvguia/master/thumbnails/next.png'))



    return itemlist


def peliculas(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    datas = re.sub(r"\n|\r|\t|\(.*?\)|\s{2}|&nbsp;", "", data)
    patron = '<div class="item"><a href="([^"]+)">.*?'  # scrapedurl
    patron += '<img alt="([^"]+)".*?'  # title
    patron += 'src="([^"]+)">'  # img
    matches = scrapertools.find_multiple_matches(datas, patron)

    for scrapedurl, scrapedtitle, scrapedthumbnail in matches[item.page:item.page + 14]:
        data = httptools.downloadpage(scrapedurl).data
        imdb_id = scrapertools.find_single_match(data, '<li>Pagina de IMDB de <a href="http://www.imdb.com/title/(.*?)"')

        itemlist.append(item.clone(channel=__channel__, action='get_findvideos', contentType='movie',
                             title=scrapedtitle, url=scrapedurl + '?ver=pelicula', text_color=color2,
                             thumbnail=scrapedthumbnail, infoLabels={'imdb_id': imdb_id}))

    if item.page + 14 < len(matches):
        itemlist.append(item.clone(page=item.page + 14, title=">> Página Siguiente", text_color=color3))
    else:
        next_page = scrapertools.find_single_match(datas, '<div class="next"><a href="([^"]+)">Siguiente</a></div>')
        if next_page:
            itemlist.append(item.clone(url=next_page, page=0, title=">> Página Siguiente", text_color=color3))

    tmdb.set_infoLabels(itemlist, __modo_grafico__)
    tmdb.set_infoLabels(itemlist, __modo_grafico__)

    return itemlist

def series(item):
    logger.info("pelisalacarta.channels.cueva series")

    itemlist = []

    data = httptools.downloadpage(item.url).data
    datas = re.sub(r"\n|\r|\t|\(.*?\)|\s{2}|&nbsp;", "", data)
    patron = '<div class="item"><a href="([^"]+)">.*?'  # scrapedurl
    patron += '<img alt="([^"]+)".*?'  # title
    patron += 'src="([^"]+)">'  # img
    matches = scrapertools.find_multiple_matches(datas, patron)

    for scrapedurl, scrapedtitle, scrapedthumbnail in matches[item.page:item.page + 14]:

        itemlist.append(item.clone(title=scrapedtitle, url=scrapedurl, contentSerieName=scrapedtitle, text_color=color2,
                                   action="temporadas", show=scrapedtitle, contentType='tvshow', page=0,
                                   thumbnail=scrapedthumbnail))

    # url_next_page = scrapertools.find_single_match(datas, '<div class="next"><a href="([^"]+)">Siguiente</a></div>')

    tmdb.set_infoLabels(itemlist, __modo_grafico__)
    tmdb.set_infoLabels(itemlist, __modo_grafico__)

    if item.page + 14 < len(matches):
        itemlist.append(item.clone(page=item.page + 14, title=">> Página Siguiente", text_color=color3))
    else:
        next_page = scrapertools.find_single_match(datas, '<div class="next"><a href="([^"]+)">Siguiente</a></div>')
        if next_page:
            itemlist.append(item.clone(url=next_page, page=0, title=">> Página Siguiente", text_color=color3))

    return itemlist


def temporadas(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    datas = re.sub(r"\n|\r|\t|&nbsp;|<br>", "", data)
    # logger.info(datas)
    patron_todas = '<div class="los_enlaces">(.*?)<div class="los_comentarios">'
    datas = scrapertools.find_single_match(datas, patron_todas)
    patron = '<label class="tab-label" for="[^"]+">([^<]+)</label>.*?'  # numeros de temporadas
    patron += 'class="imagen"><img src="([^"]+)">'  # capitulos

    matches = scrapertools.find_multiple_matches(datas, patron)
    if len(matches) > 1:
        for scrapedseason, scrapedthumbnail in matches:
            temporada = scrapertools.find_single_match(scrapedseason, '(\d+)')
            new_item = item.clone(action="episodios", season=temporada, text_color=color1, thumbnail=scrapedthumbnail.strip())
            new_item.infoLabels['season'] = temporada
            new_item.extra = ""
            itemlist.append(new_item)

        tmdb.set_infoLabels(itemlist, __modo_grafico__)
        for i in itemlist:
            i.title = "%s. %s" % (i.infoLabels['season'], i.infoLabels['tvshowtitle'])
            if i.infoLabels['title']:
                # Si la temporada tiene nombre propio añadirselo al titulo del item
                i.title += " - %s" % (i.infoLabels['title'])
            if i.infoLabels.has_key('poster_path'):
                # Si la temporada tiene poster propio remplazar al de la serie
                i.thumbnail = i.infoLabels['poster_path']

        itemlist.sort(key=lambda it: it.title)


        return itemlist
    else:
        return episodios(item)


def episodios(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    datas = re.sub(r"\n|\r|\t|&nbsp;|<br>", "", data)
    logger.info(datas)
    patron_todas = '<div class="tabs">(.*?)<div class="los_comentarios">'#num_temp
    datas = scrapertools.find_single_match(datas, patron_todas)
    patron = '<div class="episodio"><ul><div class="[^"]+"><a href="([^"]+)">.*?'  #
    patron += '<div class="num">([^<]+)</div>.*?'  # numerando cap
    patron += '<div class="name-ep">([^<]+)<span'  # title de episodios

    matches = scrapertools.find_multiple_matches(datas, patron)

    for scrapedurl, scrapedtitle, scrapedname in matches:
        patron = '(\d+) - (\d+)'
        match = re.compile(patron, re.DOTALL).findall(scrapedtitle)
        season, episode = match[0]

        if 'season' in item.infoLabels and int(item.infoLabels['season']) != int(season):
            continue

        title = "%sx%s: %s" % (season, episode.zfill(2), scrapedname)
        new_item = item.clone(title=title, url=scrapedurl, action="cap_findvideos", text_color=color2, fulltitle=title,
                              contentType="episode")
        if 'infoLabels' not in new_item:
            new_item.infoLabels = {}

        new_item.infoLabels['season'] = season
        new_item.infoLabels['episode'] = episode.zfill(2)

        itemlist.append(new_item)

    # TODO no hacer esto si estamos añadiendo a la biblioteca
    if not item.extra:
        # Obtenemos los datos de todos los capitulos de la temporada mediante multihilos
        tmdb.set_infoLabels(itemlist, __modo_grafico__)
        for i in itemlist:
            if i.infoLabels['title']:
                # Si el capitulo tiene nombre propio añadirselo al titulo del item
                i.title = "%sx%s %s" % (i.infoLabels['season'], i.infoLabels[
                                        'episode'], i.infoLabels['title'])
            if i.infoLabels.has_key('poster_path'):
                # Si el capitulo tiene imagen propia remplazar al poster
                i.thumbnail = i.infoLabels['poster_path']

    itemlist.sort(key=lambda it: int(it.infoLabels['episode']),
                  reverse=config.get_setting('orden_episodios', __channel__))

    # Opción "Añadir esta serie a la biblioteca"
    if config.get_library_support() and len(itemlist) > 0:
        itemlist.append(Item(channel=__channel__, title="Añadir esta serie a la biblioteca", url=item.url,
                             action="add_serie_to_library", extra="episodios", show=item.show, category="Series",
                             text_color=color1, thumbnail=thumbnail_host, fanart=fanart_host))

    return itemlist


def findvideos(item):
    logger.info()

    itemlist = []

    data = httptools.downloadpage(item.url, headers= headers, cookies=False).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    patron = '<iframe src="([^"]+)" scrolling="no" frameborder="0".*?</iframe>'  # scrapedtitle
    matches = re.compile(patron, re.DOTALL).findall(data)

    for url in matches:
        video_urls = []
        doc_id = scrapertools.find_single_match(url, "docid=([^&]+)&")
        doc_url = "http://docs.google.com/get_video_info?docid=%s" % doc_id
        response = httptools.downloadpage(doc_url, cookies=False)
        cookies = ""
        cookie = response.headers["set-cookie"].split("HttpOnly, ")
        for c in cookie:
            cookies += c.split(";", 1)[0] + "; "
        data = response.data.decode('unicode-escape')
        data = urllib.unquote_plus(urllib.unquote_plus(data))
        headers_string = "|Cookie=" + cookies
        url_streams = scrapertools.find_single_match(data, 'url_encoded_fmt_stream_map=(.*)')
        streams = scrapertools.find_multiple_matches(url_streams,
                                         'itag=(\d+)&url=(.*?)(?:;.*?quality=.*?(?:,|&)|&quality=.*?(?:,|&))')
        itags = {'18':'360p', '22':'720p', '34':'360p', '35':'480p', '37':'1080p', '43':'360p', '59':'480p'}
        for itag, video_url in streams:
            video_url += headers_string
            video_urls.append([video_url, itags[itag]])

        for video_item in video_urls:
            calidad = video_item[1]
            title = '%s [COLOR green](%s) (Directo)[/COLOR]'%(item.contentTitle, calidad)
            url = video_item[0]

            itemlist.append(
                item.clone(channel=__channel__,
                     action='play',
                     title=title,
                     url= url,
                     thumbnail=item.thumbnail,
                     plot=item.plot,
                     fanart=item.fanart,
                     contentTitle=item.contentTitle,
                     server='directo',
                     context = item.context
                     ))

        return itemlist


def get_findvideos(item):
    logger.info()
    itemlist = []
    itemlist = findvideos(item)
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|&nbsp;|<br>", "", data)

    patron = '<li class="clasifica"><a rel="nofollow" href="([^"]+)".*?' # url
    patron += '<img src="http://cueva.pro/sim/ckarim/ck_sources/ck_img/([^.]+).png">.*?' # lang
    patron += '<strong>(\w+).*?' # server
    patron += '<span>([^<]+)</span>' # calidad

    matches = re.compile(patron,re.DOTALL).findall(data)

    for url, lang, servidor, calidad in matches:
        data = httptools.downloadpage(url).data
        url = scrapertools.find_single_match(data, 'window.location="([^"]+)"')
        calidad = calidad.replace('MICROHD-', '').replace('TS-SCREENER', 'TS-S') .strip()
        # url = scrapedurl.replace('embed-', '').replace('.html', '')
        title = "%s [COLOR yellow](%s) (%s) (%s)[/COLOR]" % (item.contentTitle, servidor, lang, calidad)
        server = servertools.get_server_from_url(url)
        itemlist.append(item.clone(title=title, url=url, server=server, action='play'))

    return itemlist


def cap_findvideos(item):
    logger.info()
    itemlist = []
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|&nbsp;|<br>", "", data)
    # logger.info(data)

    patron = '<li id="[^"]+" data-url="([^"]+)".*?' # url
    patron += '<img src="http://cueva.pro/sim/ckarim/ck_sources/ck_img/(.*?).png">.*?' # idioma
    patron += '<strong>([^<]+)</strong>.*?' # servidor
    patron += '<span>([^<]+)<b>[^<]+</b></span>' # calidad.strip()

    matches = re.compile(patron,re.DOTALL).findall(data)

    for scrapedurl, lang, servidor, calidad in matches:
        scrapedurl = scrapedurl.replace('embed-', '').replace('streamplay.to/', 'streamplay.to/player-')
        calidad = calidad.replace('MICROHD-', '')
        title = "%s [%s] [%s] [%s]" % (item.title.strip(), servidor.title(), lang, calidad.strip())
        server = servertools.get_server_from_url(scrapedurl)
        itemlist.append(item.clone(title=title, url=scrapedurl, server=server, action='play'))
    tmdb.set_infoLabels(itemlist, __modo_grafico__)

    return itemlist

def newest(categoria):
    logger.info()
    itemlist = []
    item = Item()
    item.page = 0
    try:
        if categoria == 'peliculas':
            # item.url = item.url = urlparse.urljoin(CHANNEL_HOST, "movies/all/")
            item.url = host + 'ver-peliculas-online'
        else:
            return []

        itemlist = peliculas(item)
        if itemlist[-1].title == ">> Página siguiente":
            itemlist.pop()

    # Se captura la excepción, para no interrumpir al canal novedades si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("{0}".format(line))
        return []

    return itemlist
