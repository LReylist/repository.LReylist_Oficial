# -*- coding: iso-8859-1 -*-
#------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Conector para backin.net
# by be4t5
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
#------------------------------------------------------------

import re

from core import logger
from core import scrapertools


def get_video_url( page_url , premium = False , user="" , password="", video_password="" ):
    logger.info("pelisalacarta.servers.cnubis page_url="+page_url)
    video_urls = []
 
    data = scrapertools.cache_page(page_url)
    matches = scrapertools.find_multiple_matches(data, 'data-src-mp4-(\w+)="([^"]+)"')
    for calidad, media_url in matches:
        ext = "%s %s" % (media_url[-4:], calidad.upper())
        video_urls.append([ext + " [cnubis]", media_url])

    for video_url in video_urls:
       logger.info("pelisalacarta.servers.cnubis %s - %s" % (video_url[0],video_url[1]))

    return video_urls

# Encuentra v�deos de este servidor en el texto pasado
def find_videos(text):
    encontrados = set()
    devuelve = []

    # https://cnubis.com/plugins/mediaplayer/site/_1embed.php?u=9mk&w=640&h=320
    # http://cnubis.com/plugins/mediaplayer/site/_2embed.php?u=2aZD
    # http://cnubis.com/plugins/mediaplayer/embed/_2embed.php?u=U6w
    patronvideos  = 'cnubis.com/plugins/mediaplayer/(.*?/[^.]+.php\?u\=[A-Za-z0-9]+)'
    logger.info("pelisalacarta.servers.cnubis find_videos #"+patronvideos+"#")
    matches = re.compile(patronvideos,re.DOTALL).findall(text)

    for match in matches:
        titulo = "[cnubis]"
        url = "http://cnubis.com/plugins/mediaplayer/%s" % (match)
        if url not in encontrados and id != "":
            logger.info("  url="+url)
            devuelve.append( [ titulo , url , 'cnubis' ] )
            encontrados.add(url)
        else:
            logger.info("  url duplicada="+url)        

    return devuelve
