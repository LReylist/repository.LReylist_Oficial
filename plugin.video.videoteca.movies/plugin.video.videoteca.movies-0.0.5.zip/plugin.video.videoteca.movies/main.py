# coding: utf-8
# Main Addon
__author__ = 'mancuniancol'

from xbmcswift2 import Plugin
from tools2 import *

##INITIALISATION
storage = Storage(settings.storageName, type="dict")
plugin = Plugin()


###############################
###  MENU    ##################
###############################
@plugin.route('/')
def index():
    genresDict = readOptions(settings.value["urlAddress"])
    items = [
        {'label': " Busqueda Manual",
         'path': plugin.url_for('search'),
         'thumbnail': dirImages("busqueda-manual.png"),
         'properties': {'fanart_image': settings.fanart}
         },
        {'label': " AYUDA",
         'path': plugin.url_for('help'),
         'thumbnail': dirImages("ayuda.png"),
         'properties': {'fanart_image': settings.fanart}
         }
    ]

    for type, url in genresDict.iteritems():
        if type in storage.database.keys():
            importInfo = (settings.string(32001),
                          'XBMC.Container.Update(%s)' % plugin.url_for('unsubscribe', key=type))
        else:
            importInfo = (settings.string(32002),
                          'XBMC.Container.Update(%s)' % plugin.url_for('subscribe', key=type, url=url))
        items.append({'label': type,
                      'path': plugin.url_for('readItems', url=url),
                      'thumbnail': dirImages(type + ".png"),
                      'properties': {'fanart_image': settings.fanart},
                      'context_menu': [importInfo, (plugin.get_string(32009),
                                                    'XBMC.RunPlugin(%s)' % plugin.url_for('importAll', key=type,
                                                                                          url=url))]
                      })
    return plugin.finish(items, sort_methods=['date'])


@plugin.route('/help/')
def help():
    textViewer("Visite http://tutvguia.com/forums/ por asistencia", once=False)


@plugin.route('/search/')
def search():
    query = settings.dialog.input("Cual película buscar?")
    url = "%s/es/peliculas/custom/?search=%s" % (settings.value["urlAddress"], query)
    return readItems(url)


@plugin.route('/play/<url>')
def play(url):
    uri_string = quote_plus(url)
    # Set-up the plugin
    channel = "yaske"
    link = "plugin://plugin.video.pelisalacarta/?channel=%s&action=play_from_library&url=%s" % (channel, uri_string)
    # play media
    settings.debug("PlayMedia(%s)" % link)
    xbmc.executebuiltin("PlayMedia(%s)" % link)
    xbmc.executebuiltin('Dialog.Close(all, true)')


@plugin.route('/importOne/<title>')
def importOne(title=""):
    information = plugin.get_storage('information')
    info = information[title]
    integration(titles=[info.title], magnets=[info.fileName], id=[info.id], typeVideo=[info.typeVideo], silence=True)


@plugin.route('/unsubscribe/<key>')
def unsubscribe(key=""):
    storage.remove(key)
    storage.save()


@plugin.route('/subscribe/<key>/<url>')
def subscribe(key="", url=""):
    storage.add(key, url)
    storage.save()
    importAll(key, url)


@plugin.route('/importAll/<url>')
def importAll(url=""):
    items = readItems(url)  # only to create information
    information = plugin.get_storage('information')
    titles = []
    magnets = []
    typeVideo = []
    id = []
    # read information from Storage
    for key in information:
        titles.append(information[key].title)
        magnets.append(information[key].fileName)
        typeVideo.append(information[key].typeVideo)
        id.append(information[key].id)
    integration(titles=titles, magnets=magnets, id=id, typeVideo=typeVideo, silence=True)


@plugin.route('/readItems/<url>', name="readItems")
@plugin.route('/nextPage/<url>/<page>', name="nextPage")
def readItems(url="", page="1"):
    # read from URL
    settings.log(url)
    response = browser.get(url)
    soup = bs4.BeautifulSoup(response.text)
    links = soup.select("li.item-movies a.image-block")

    #Storage information
    information = plugin.get_storage('information')
    information.clear()
    information.sync()

    # Items Menu Creation
    items = []
    typeVideo = ""
    for a in links:
        title = a.get("title", "")  # define title
        urlSource = a["href"]  # define url
        info = UnTaggle(title, urlSource)  # it gets all the information from the title and url
        information[title] = info  # save for importAll
        typeVideo = info.typeVideo
        try:
            items.append({'label': info.label,
                          'path': plugin.url_for('play', url=urlSource),
                          'thumbnail': info.cover,
                          'properties': {'fanart_image': info.fanart},
                          'info': info.info,
                          'stream_info': info.infoStream,
                          'context_menu': [
                              (plugin.get_string(32009),
                               'XBMC.RunPlugin(%s)' % plugin.url_for('importOne', title=title))
                          ]
                          })
        except:
            pass
    information.sync()
    # SetContent
    if typeVideo != "MOVIE":
        typeVideo = "episodes"
    else:
        typeVideo = "movies"
    # main
    if __name__ == '__main__':
        plugin.set_content(typeVideo)
    # next page
    items.append({'label': "Página Siguiente..",
                  'path': plugin.url_for('nextPage',
                                         url=changeUrl(url) % (int(page) + 1), page=int(page) + 1),
                  'thumbnail': settings.icon,
                  'properties': {'fanart_image': settings.fanart}
                  })
    return items


def changeUrl(url):
    if url == "http://www.yaske.cc":
        url += "/es/peliculas/page/%s"
    elif 'page' in url:
        url = re.sub("[0-9]+", "%s", url)
    else:
        url = url.replace("/peliculas/", "/peliculas/page/%s/")
    return url


def readOptions(url=""):
    result = None
    goodSpider()
    response = browser.get(url)  # open the serie
    if response.status_code == requests.codes.ok:
        soup = bs4.BeautifulSoup(response.text)
        genres = {" TODAS": "http://www.yaske.cc"}
        links = soup.select('form#form_custom select#genres option')
        links.pop(0)
        for link in links:
            genres[link.text] = "%s/es/peliculas/genero/%s" % (settings.value["urlAddress"], link.attrs.get("value"))
        result = genres
    else:
        settings.log(">>>>>>>HTTP %s<<<<<<<" % response.status_code)
        settings.notification(message="HTTP %s" % response.status_code, force=True)
    return result


if __name__ == '__main__':
    plugin.run()
