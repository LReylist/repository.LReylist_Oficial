# -*- coding: utf-8 -*-
######################
#IPTV Europa
#####################



import os
import sys
import urllib
import urllib2
import shutil
import base64

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import tools
import plugintools
import datetime
import re
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.IPTV_Europa/art', ''))
MEN = "http://de.seaicons.com/wp-content/uploads/2015/06/key-icon.png"
tv = "http://www.aoc.com.br/assets/aoc-brasil/media/product/main/20170206114359554_100753.png"
can = "https://marketingventasparatodos.files.wordpress.com/2012/10/dinero-candado-seguridad.jpg"
estati = "http://wachtvworld.org/gallery_gen/0bf9f907238217b60f337d5d4695f7f9.jpg"
referer = 'http://www.seriesflv.com/'
thumbnail = 'http://aldocarranza.hol.es/wp-content/uploads/2014/07/iTunes-icon-150x150.png'
lista = 'http://icon-icons.com/icons2/159/PNG/256/list_tasks_22372.png'
music = "https://cdn3.iconfinder.com/data/icons/66-cds-dvds/512/Icon_60-512.png"
pel = "https://seeklogo.com/images/M/movie-time-cinema-logo-8B5BE91828-seeklogo.com.png"
nopor = "http://www.jshotels.com/sites/default/files/js-hotels-only-adults-18.png"
eve = "http://jvinsidercircle.com/members/images/calendar.png"
THUMBNAIL = "thumbnail"
TV_SHOWS = "tvshows"
wachusername = plugintools.get_setting("wachusername")
wachpass = plugintools.get_setting("wachpass")
morros = plugintools.get_setting("morros")
url = "http://ariaccess.com:25461/enigma2.php?username=" + wachusername + "&password=" + wachpass + "&type=get_live_categories"
yea = "http://ariaccess.com:25461/enigma2.php?username=" + wachusername + "&password=" + wachpass 
chifu = "&type=get_vod_streams&cat_id="



def run():
    plugintools.log("IPTV Europa.run")
    params = plugintools.get_params()
    if params.get("action") is None:
        xtv(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    plugintools.close_item_list()
	
	
def xtv(params):
  xtvmaster = plugintools.get_setting("xtvmaster")
  

  if xtvmaster == 'false':
   plugintools.message("IPTV Europa","ACCEDE PRIMERO AL PORTAL")
   plugintools.open_settings_dialog()
  else:
        data = tools.OPEN_URL(url + "0")
        
        if "<items>" in data:
           main_list(params)
        elif "" in data:
           xbmc.executebuiltin("Notification(%s,%s,%s,%s)" % ('IPTV Europa', "USUARIO O CONTRASEÑA INCORRECTA......", 10 , art+'b.png')) 
           plugintools.open_settings_dialog()

def main_list(params):
    plugintools.log("IPTV Europa.main_list "+repr(params))
    plugintools.set_view(THUMBNAIL)
    plugintools.add_item( 
        action = "accountinfo", 
        title = "MI CUENTA",
        thumbnail = MEN,
        fanart = can,
        folder = True )
    plugintools.add_item( 
        action = "perro2", 
        title = "TV ONLINE",
        thumbnail = art+'tv2.png',
        fanart = art+'f.jpg',
        url = url,
        folder = True )
    plugintools.add_item( 
        action = "perro3", 
        title = "PELICULAS Y SERIES",
        thumbnail = art+'pel.png',
        fanart = art+'f.jpg',
        url = yea + "&type=get_vod_categories",
        folder = True )
    plugintools.add_item( 
        action = "menu3", 
        title = "EXTRAS",
        thumbnail = "http://icons.iconarchive.com/icons/graphicloads/flat-finance/256/settings-icon.png",
        fanart = art+'f.jpg',
        folder = True )

    if morros == "true" :
	plugintools.add_item( 
        action = "perro", 
        title = "SOLO ADULTOS ",
        url = "http://wachtv.org:8000/enigma2.php?username=" + wachusername + "&password=" + wachpass + "&type=get_live_streams&cat_id=" + "41",
        thumbnail = nopor,
        fanart = estati,
        folder = True )
    

#http://ariaccess.com:25461/get.php?username=Diegoverna&password=Diegoverna&type=m3u_plus&output=ts

		
def parse2(params):
    plugintools.log("parse "+repr(params))
    plugintools.set_view(THUMBNAIL)
    plugintools.add_item( 
        action = "perro", 
        title = "MUSICA VIDEOS",
        url = "http://wachtv.org:8000/enigma2.php?username=" + wachusername + "&password=" + wachpass + "&type=get_live_streams&cat_id=19",
        thumbnail = music,
        folder = True )
    plugintools.add_item(
        action = "search5",
        title = "MUSICA AL GUSTO",
        thumbnail = music,
        folder = True )
		
def parse3(params):
    plugintools.log("parse "+repr(params))
    plugintools.set_view(THUMBNAIL)
    plugintools.add_item( 
        action = "perro", 
        title = "SERIES",
        url = yea + chifu + "33",
        thumbnail = music,
        folder = True )
    plugintools.add_item(
        action = "search5",
        title = "PELICULAS",
        thumbnail = music,
        folder = True )

		
def menu3(params):
    plugintools.log("parse "+repr(params))
    plugintools.set_view(THUMBNAIL)
    plugintools.add_item( 
        action = "clear_cache", 
        title = "BORRAR CACHE",
        url = yea + chifu + "33",
        fanart = art+'f.jpg',
        thumbnail = "http://es.seaicons.com/wp-content/uploads/2016/10/Delete-icon.png",
        folder = False )

#http://usa.01.cdnstreams.in:6034/viewsa/ch20q1.stream/playlist.m3u8?
		
		
def perro(params):
    plugintools.set_view(TV_SHOWS)
    url = params.get("url")
    data = tools.OPEN_URL(url)
    
    SongLists = plugintools.find_multiple_matches(data, '<channel>(.*?)</channel>')
    for entry in SongLists:
            ima = plugintools.find_single_match(entry, '<desc_image>([^"]+)</desc_image>')
            ima = ima.replace("<![CDATA[", "")
            ima = ima.replace("]]>", "")
            titulo = plugintools.find_single_match(entry, '<title>([^"]+)</title>')
            titulo = base64.b64decode(titulo)
            titulo = titulo.upper()
            titulo = titulo.replace("PARENT-CODE=\"6666\"","")
            description = plugintools.find_single_match(entry, '<description>([^"]+)</description>')
            description = base64.b64decode(description)
            playstation = plugintools.find_single_match(entry, '<stream_url>([^"]+)</stream_url>')
            playstation = playstation.replace("<![CDATA[", "")
            playstation = playstation.replace("]]>", "")
            #playstation = playstation.replace(".ts", ".m3u8")
            plugintools.add_item(action="play", title = titulo , plot = description , url = playstation , thumbnail = ima , fanart = ima , info_labels = None , folder = False, isPlayable = True)


def perro2(params):
    plugintools.set_view(THUMBNAIL)
    url = params.get("url")
    data = tools.OPEN_URL(url)
    
    SongLists = plugintools.find_multiple_matches(data, '<channel>(.*?)</channel>')
    for entry in SongLists:
     ima = plugintools.find_single_match(entry, '<desc_image>([^"]+)</desc_image>')
     ima = ima.replace("<![CDATA[", "")
     ima = ima.replace("]]>", "")
     playstation = plugintools.find_single_match(entry, '<playlist_url>([^"]+)</playlist_url>')
     playstation = playstation.replace("<![CDATA[", "")
     playstation = playstation.replace("]]>", "")
     titulo = plugintools.find_single_match(entry, '<title>([^"]+)</title>')
     titulo = base64.b64decode(titulo)
     titulo = titulo.upper()
     if titulo.find("") >= 0:
        plugintools.add_item(action="perro", title = titulo , url = playstation , thumbnail = art+'tv2.png' , fanart  = art+'I.png'  , folder = True)
  
#SOLO MEXICO		
		 
def perro3(params):
    plugintools.set_view(TV_SHOWS)
    url = params.get("url")
    data = tools.OPEN_URL(url)
    
    SongLists = plugintools.find_multiple_matches(data, '<channel>(.*?)</channel>')
    for entry in SongLists:
        ima = plugintools.find_single_match(entry, '<desc_image>([^"]+)</desc_image>')
        ima = ima.replace("<![CDATA[", "")
        ima = ima.replace("]]>", "")
        titulo = plugintools.find_single_match(entry, '<title>([^"]+)</title>')
        titulo = base64.b64decode(titulo)
        titulo = titulo.upper()
        titulo = titulo.replace("PARENT-CODE=\"6666\",","")
        description = plugintools.find_single_match(entry, '<description>([^"]+)</description>')
        description = base64.b64decode(description)
        playstation = plugintools.find_single_match(entry, '<playlist_url>([^"]+)</playlist_url>')
        playstation = playstation.replace("<![CDATA[", "")
        playstation = playstation.replace("]]>", "")
        if playstation.find("get_vod_scategories") >= 0:
            plugintools.add_item(action="perro5", title = titulo + " " + '[COLOR blue][SERIES][/COLOR]', plot = description , url = playstation , thumbnail = ima , fanart = art+'I.png' , info_labels = None , folder = True, isPlayable = False)
        if playstation.find("get_vod_streams") >= 0:
            plugintools.add_item(action="perro4", title = titulo, plot = description , url = playstation , thumbnail = ima , fanart = art+'f.jpg' , info_labels = None , folder = True, isPlayable = False)			
			

def perro5(params):
    plugintools.set_view(TV_SHOWS)
    url = params.get("url")
    data = tools.OPEN_URL(url)
    
    SongLists = plugintools.find_multiple_matches(data, '<channel>(.*?)</channel>')
    for entry in SongLists:
            ima2 = plugintools.find_single_match(entry, '<desc_image>([^"]+)</desc_image>')
            ima2 = ima2.replace("<![CDATA[", "")
            ima2 = ima2.replace("]]>", "")
            titulo2 = plugintools.find_single_match(entry, '<title>([^"]+)</title>')
            titulo2 = base64.b64decode(titulo2)
            titulo2 = titulo2.upper()
            titulo2 = titulo2.replace("PARENT-CODE=\"6666\",","")
            description2 = plugintools.find_single_match(entry, '<description>([^"]+)</description>')
            description2 = base64.b64decode(description2)
            playstation2 = plugintools.find_single_match(entry, '<playlist_url>([^"]+)</playlist_url>')
            playstation2 = playstation2.replace("<![CDATA[", "")
            playstation2 = playstation2.replace("]]>", "")
            plugintools.add_item(action="perro4", title = titulo2 , plot = description2 , url = playstation2 , thumbnail = ima2 , fanart = ima2 , info_labels = None , folder = True, isPlayable = True)			

			
			
			
def play2(params):
    plugintools.set_view(THUMBNAIL)
    url = params.get("url")
    plugintools.play_resolved_url(url)


def play(params):
    plugintools.set_view(TV_SHOWS)
    url = params.get("url")
    plugintools.play_resolved_url(url)
	
	
	
	
def perro4(params):
    plugintools.set_view(TV_SHOWS)
    url = params.get("url")
    data = tools.OPEN_URL(url)
    
    SongLists = plugintools.find_multiple_matches(data, '<channel>(.*?)</channel>')
    for entry in SongLists:
            ima2 = plugintools.find_single_match(entry, '<desc_image>([^"]+)</desc_image>')
            ima2 = ima2.replace("<![CDATA[", "")
            ima2 = ima2.replace("]]>", "")
            titulo2 = plugintools.find_single_match(entry, '<title>([^"]+)</title>')
            titulo2 = base64.b64decode(titulo2)
            titulo2 = titulo2.upper()
            titulo2 = titulo2.replace("PARENT-CODE=\"6666\",","")
            description2 = plugintools.find_single_match(entry, '<description>([^"]+)</description>')
            description2 = base64.b64decode(description2)
            playstation2 = plugintools.find_single_match(entry, '<stream_url>([^"]+)</stream_url>')
            playstation2 = playstation2.replace("<![CDATA[", "")
            playstation2 = playstation2.replace("]]>", "")
            plugintools.add_item(action="play", title = titulo2 , plot = description2 , url = playstation2 , thumbnail = ima2 , fanart = art+'I.png' , info_labels = None , folder = False, isPlayable = True)
	
def search5(params):
    dialog = xbmcgui.Dialog()
    selector = dialog.select('WACHTV', ['BUSQUEDA POR CANCION', 'BUSQUEDA POR ARTISTA'])
    if selector == 0:
        texto = plugintools.keyboard_input()
        plugintools.set_setting("last_search",texto)
        busqueda = 'http://www.goear.com/apps/android/search_songs_json.php?q='+ texto
        busqueda  = busqueda.replace(' ', "+")
        data = gethttp_referer_headers(busqueda,referer)
        if "id" in data:
           plugintools.log("busqueda= "+busqueda)
           songs = plugintools.find_multiple_matches(data, '{(.*?)}')
           for entry in songs:
            plugintools.log("entry= "+entry)
            id_song = plugintools.find_single_match(entry, '"id":"([^"]+)')
            plugintools.log("id_song= "+id_song)
            title_song = plugintools.find_single_match(entry, '"title":"([^"]+)')
            title_song = title_song.upper()
            plugintools.log("title_song= "+title_song)
            songtime = plugintools.find_single_match(entry, '"songtime":"([^"]+)')
            plugintools.log("songtime= "+songtime)
            url='http://www.goear.com/action/sound/get/'+id_song
            plugintools.log("url= "+url)
            plugintools.add_item(action="play2", title = title_song + " " +'[COLOR orange] ('+songtime+')[/COLOR]', url=url, thumbnail = thumbnail , fanart = "" , folder = False, isPlayable = True)
        elif "0" in data:
             errormsg = plugintools.message("","SIN RESULTADOS")
             search5(params)
    if selector == 1:
        texto = plugintools.keyboard_input()
        plugintools.set_setting("last_search",texto)
        url = 'http://www.goear.com/apps/android/search_playlist_json.php?q='+texto
        plugintools.log("url= "+url)
        url2  = url.replace(' ', "+")
        data = gethttp_referer_headers(url2,referer)
        if "id" in data:
           songs = plugintools.find_multiple_matches(data, '{(.*?)}')
           i = 1
           for entry in songs:
            plugintools.log("entry= "+entry)
            id_song = plugintools.find_single_match(entry, '"id":"([^"]+)')
            plugintools.log("id_song= "+id_song)
            url = 'http://www.goear.com/apps/android/playlist_songs_json.php?v='+id_song 
            title_song = plugintools.find_single_match(entry, '"title":"([^"]+)')
            title_song = title_song.upper()			
            plugintools.log("title_song= "+title_song)
            plsongs = plugintools.find_single_match(entry, '"plsongs":"([^"]+)"')
            songtime = plugintools.find_single_match(entry, '"songtime":"([^"]+)')
            plugintools.add_item(action="songs2", title = title_song + " " + '[COLOR red]('+ plsongs +')[/COLOR]' + 'ITEMS' + '[COLOR orange] ('+songtime+')[/COLOR]' +  'DURACION'  , url = url , thumbnail = lista , fanart = ""  , folder = True, isPlayable = False)
            i = i + 1			
        elif "0" in data:
             errormsg = plugintools.message("","SIN RESULTADOS")
             search5(params)		
           

		   
		   
def songs2(params):
        url = params.get("url")
        data = gethttp_referer_headers(url,referer)
        songs2 = plugintools.find_multiple_matches(data, '{(.*?)}')
        i = 1
        for entry in songs2:
            plugintools.log("entry= "+entry)
            id_song = plugintools.find_single_match(entry, '"id":"([^"]+)')
            plugintools.log("id_song= "+id_song)
            title_song = plugintools.find_single_match(entry, '"title":"([^"]+)')
            title_song = title_song.upper()
            plugintools.log("title_song= "+title_song)
            songtime = plugintools.find_single_match(entry, '"songtime":"([^"]+)')
            plugintools.log("songtime= "+songtime)
            url='http://www.goear.com/action/sound/get/'+id_song
            plugintools.log("url= "+url)
            plugintools.add_item(action="play2", title = title_song + " " +'[COLOR orange] ('+songtime+')[/COLOR]', url=url, thumbnail = thumbnail , fanart = "" , folder = False, isPlayable = True)
            i = i + 1








def gethttp_referer_headers(url,referer):    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31"])
    request_headers.append(["Referer", referer])    
    body,response_headers = plugintools.read_body_and_headers(url, headers=request_headers)
    return body



	
	
def clear_cache(params):
	xbmc.log('CLEAR CACHE ACTIVATED')
	xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
	confirm=xbmcgui.Dialog().yesno("POR FAVOR CONFIRME","CONFIRME QUE DESEA BORRAR DATOS DE KODI","","","CANCEL","BORRAR")
	if confirm:
		if os.path.exists(xbmc_cache_path)==True:
			for root, dirs, files in os.walk(xbmc_cache_path):
				file_count = 0
				file_count += len(files)
				if file_count > 0:


						for f in files:
							try:
								os.unlink(os.path.join(root, f))
							except:
								pass
						for d in dirs:
							try:
								shutil.rmtree(os.path.join(root, d))
							except:
								pass


		dialog = xbmcgui.Dialog()
		dialog.ok("IPTV Europa", "CACHE ELIMINADA CON EXITO!")
		xbmc.executebuiltin("Container.Refresh()")
		main_list(params)		

	

	
def accountinfo(params):
    plugintools.set_view(THUMBNAIL)

    open = 'http://ariaccess.com:25461/panel_api.php?username=' + wachusername + "&password=" + wachpass
    request_headers=[]
    request_headers.append(["User-Agent","Kodi plugin by Europa"])
    body,response_headers = plugintools.read_body_and_headers(open, headers=request_headers)
    username   = tools.regex_from_to(body,'"username":"','"')
    plugintools.log("username= "+username)    
    password   = tools.regex_from_to(body,'"password":"','"')
    status     = tools.regex_from_to(body,'"status":"','"')
    status = status.upper()
    connects   = tools.regex_from_to(body,'"max_connections":"','"')
    active     = tools.regex_from_to(body,'"active_cons":"','"')
    expiry     = tools.regex_from_to(body,'"exp_date":"','"')
    expiry     = datetime.datetime.fromtimestamp(int(expiry)).strftime('%d/%m/%Y - %H:%M')
    expreg     = re.compile('^(.*?)/(.*?)/(.*?)$',re.DOTALL).findall(expiry)
    for day,month,year in expreg:
      month     = tools.MonthNumToName(month)
      year      = re.sub(' -.*?$','',year)
      expiry    = month+' '+day+' - '+year
      expiry  = expiry .upper()
      ip        = tools.getlocalip()
      extip     = tools.getexternalip()
      plugintools.add_item(action="", title = "USERNAME:" + " " + username , url = "" , thumbnail = "http://es.seaicons.com/wp-content/uploads/2015/11/User-icon.png" , fanart = art+'f.jpg'  , folder = False)
      plugintools.add_item(action="main_list", title = "PASSWORD:" + " " + password , url = "" , thumbnail = "http://icons.iconarchive.com/icons/hopstarter/soft-scraps/256/Lock-Lock-icon.png" , fanart = art+'f.jpg'  , folder = False)
      plugintools.add_item(action="", title = "STATUS:" + " " + status , url = "" , thumbnail = "http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/256/Status-dialog-warning-icon.png" , fanart = art+'f.jpg'  , folder = False)
      plugintools.add_item(action="", title = "EXPIRY:" + " " + expiry , url = "" , thumbnail = "https://cdn4.iconfinder.com/data/icons/flat-icon-set/2133/flat_icons-graficheria.it-06.png" , fanart = art+'f.jpg'  , folder = False)
      plugintools.add_item(action="", title = "IP INTERNA:" + " " + ip  , url = "" , thumbnail = "http://pngimages.net/sites/default/files/ip-png-image-64373.png" , fanart = art+'f.jpg'  , folder = False)
      plugintools.add_item(action="", title = "IP EXTERNA:" + " " + extip , url = "" , thumbnail = "http://pngimages.net/sites/default/files/ip-png-image-64373.png" , fanart = art+'f.jpg'  , folder = False)
			
		
run()