# -*- coding: utf-8 -*-
import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib2, json
import urlparse
from urlparse import parse_qsl

my_addon = xbmcaddon.Addon()
my_path = my_addon.getAddonInfo('path').decode('utf-8')
args = urlparse.parse_qs(sys.argv[2][1:])
# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Parametros Flooxer
flooxerApiUrl   = 'https://servicios.flooxer.com/api/'
videoApiURLBase = flooxerApiUrl + 'video/'

# Vista miniatura
skin_used = xbmc.getSkinDir()
if skin_used == 'skin.confluence':
    xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view

def get_categories():
    categories = []
    categories.append({'title': 'Original',     'name': 'original',  'tipo': 1, 'url': flooxerApiUrl + 'video/original?page=0&size=500'})
    categories.append({'title': 'Primero Aquí', 'name': 'premiere',  'tipo': 1, 'url': flooxerApiUrl + 'video/premiere?page=0&size=500'})
    categories.append({'title': 'Populares',    'name': 'populares', 'tipo': 1, 'url': flooxerApiUrl + 'video/?orderBy=hits%20desc&page=0&size=500'})
    categories.append({'title': 'Ultimos',      'name': 'ultimos',   'tipo': 1, 'url': flooxerApiUrl + 'video/?orderBy=publicationdate%20desc&page=0&size=500'})
    categories.append({'title': 'Creadores',    'name': 'creadores', 'tipo': 2, 'url': 'prescriber'})
    categories.append({'title': 'Formatos',     'name': 'formatos',  'tipo': 2, 'url': 'format'})
    categories.append({'title': 'Canales',      'name': 'canales',   'tipo': 2, 'url': 'channel'})
    categories.append({'title': 'Géneros',      'name': 'generos',   'tipo': 2, 'url': 'genre'})
    return categories

def list_categories():
    # Get video categories
    categories = get_categories()
    listing = []

    for category in categories:
        icon = '%s/icon.png' %my_path

        list_item = xbmcgui.ListItem(label=category['title'], iconImage=icon)
        if category['tipo'] == 1:
            url = '{0}?action=listing&category={1}'.format(_url, category['name'])
        else:
            url = '{0}?action=items&category={1}'.format(_url, category['name'])
        is_folder = True
        listing.append((url, list_item, is_folder))

    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

def get_videos(category):
    xbmc.log('get_videos: ' + category)

    # Buscamos la URL de la categoria
    categories = get_categories()
    for cat in categories:
        if cat['name'] == category:
            jsonUrl = cat['url']

    if jsonUrl[:4] != 'http':
        jsonUrl = '{0}{1}/?orderBy=name%20asc&page=0&size=500'.format(flooxerApiUrl,jsonUrl)

    # Peticion del JSON
    jsonSrc = makeRequest(jsonUrl)
    #xbmc.log("Recibido jsonSrc: " + jsonSrc)

    # Comprobar formato respuesta
    if (is_json(jsonSrc) == False):
        errorTitle = 'Respuesta no JSON'
        errorMsg = "La respuesta recibida no tiene formato JSON"
        mostrar_errores(errorTitle, errorMsg, jsonSrc)
        return

    # Cargar respuesta en json
    datos = json.loads(jsonSrc)

    # Comprobar error en la respuesta
    if ('error' in datos):
        errorTitle = 'Error procesando ví­deos'
        errorMsg = datos['msg']
        mostrar_errores(errorTitle, errorMsg)
        return

    # Devolvemos listado de videos
    videos = datos['content']
    #xbmc.log("Videos:\n" + str(videos))
    return(videos)

def get_videos2(category,item_id):
    xbmc.log('get_videos2: ' + category)

    # Buscamos la URL de la categoria
    categories = get_categories()
    for cat in categories:
        if cat['name'] == category:
            jsonUrl = cat['url']

    jsonUrl = '{0}{1}/{2}/videos/?&orderBy=publicationdate%20desc&page=0&size=500'.format(flooxerApiUrl,jsonUrl,item_id)

    #xbmc.log('jsonUrl: ' + jsonUrl)

    # Peticion del JSON
    jsonSrc = makeRequest(jsonUrl)
    #xbmc.log("Recibido jsonSrc: " + jsonSrc)

    # Comprobar formato respuesta
    if (is_json(jsonSrc) == False):
        errorTitle = 'Respuesta no JSON'
        errorMsg = "La respuesta recibida no tiene formato JSON"
        mostrar_errores(errorTitle, errorMsg, jsonSrc)
        return

    # Cargar respuesta en json
    datos = json.loads(jsonSrc)

    # Comprobar error en la respuesta
    if ('error' in datos):
        errorTitle = 'Error procesando vÃ­deos'
        errorMsg = datos['msg']
        mostrar_errores(errorTitle, errorMsg)
        return

    # Devolvemos listado de videos
    videos = datos['content']
    #xbmc.log("Videos:\n" + str(videos))
    return(videos)

def list_videos(category,item_id=''):
    if item_id == '':
        videos = get_videos(category)
    else:
        videos = get_videos2(category,item_id)

    listing = []
    for video in videos:

        # ID del contenido
        videoId = video['id']
        #xbmc.log('videoId: ' + videoId)

        # Comprobar el tipo de json
        if ('datos' in video):
            # Portada
            json_type = 1
        else:
            # Resto de categorias
            json_type = 2
        xbmc.log('JSON Tipo: ' + str(json_type))

        # Leemos los datos en funcion del tipo de json
        if json_type == 1:
            imgPoster = video['datos']['imgPoster']
            titulo = video['datos']['titulo']
        elif json_type == 2:
            imgPoster = video['imgPoster']
            titulo = video['titulo']

        # Imagenes del video
        videoThumb  = imgPoster + '52.jpg'
        videoIcon   = imgPoster + '54.jpg'
        videoFanart = imgPoster + '54.jpg'

        # Generar item
        list_item = xbmcgui.ListItem(label=titulo)
        list_item.setInfo('video', {'title': titulo, 'genre': 'Sin especificar'})
        list_item.setArt({'thumb': videoThumb, 'icon': videoIcon, 'fanart': videoFanart})
        list_item.setProperty('IsPlayable', 'true')
        url = '{0}?action=play&video={1}'.format(_url, videoId)
        is_folder = False
        listing.append((url, list_item, is_folder))

    # Generar listado
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

def list_items(category):
    videos = get_videos(category)

    listing = []
    for video in videos:

        # ID del contenido
        itemId = video['id']
        #xbmc.log('videoId: ' + videoId)

        # Comprobar el tipo de json
        if ('datos' in video):
            # Portada
            json_type = 1
        else:
            # Resto de categorias
            json_type = 2
        xbmc.log('JSON Tipo: ' + str(json_type))

        # Leemos los datos en funcion del tipo de json
        if json_type == 1:
            imgPoster = video['datos']['imghead']
            titulo = video['datos']['name']
        elif json_type == 2:
            imgPoster = video['imghead']
            titulo = video['name']

        # Imagenes del video
        videoThumb  = imgPoster + '52.jpg'
        videoIcon   = imgPoster + '54.jpg'
        videoFanart = imgPoster + '54.jpg'

        # Generar item
        list_item = xbmcgui.ListItem(label=titulo)
        list_item.setInfo('video', {'title': titulo, 'genre': 'Sin especificar'})
        list_item.setArt({'thumb': videoThumb, 'icon': videoIcon, 'fanart': videoFanart})
        #list_item.setProperty('IsPlayable', 'true')
        url = '{0}?action=listing2&item={1}&category={2}'.format(_url, itemId, category)
        is_folder = True
        listing.append((url, list_item, is_folder))

    # Generar listado
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

def play_video(video_id):

    # URL del video
    videoApiURL   = videoApiURLBase + video_id
    videoJsonSrc  = urllib2.urlopen(videoApiURL)
    videoJsonData = json.load(videoJsonSrc)
    videoUrl      = videoJsonData['sources'][2]['src']

    ff=open('C:/Users/Javier/AppData/Roaming/Kodi/addons/plugin.video.flooxer/datos.txt','w+')
    ff.write('videoApiURLBase=%s\n\n' %videoApiURLBase)
    ff.write('videoApiURL=%s\n\n' %videoApiURL)
    ff.write('videoJsonData=%s\n\n' %videoJsonData)
    ff.write('videoUrl=%s' %videoUrl)
    ff.close()

    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=videoUrl)

    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)

def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring
    :param paramstring:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'],'')
        elif params['action'] == 'items':
            # Play a video from a provided URL.
            list_items(params['category'])
        if params['action'] == 'listing2':
            # Display the list of videos in a provided category.
            list_videos(params['category'],params['item'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()

# Realizar peticion HTTP
def makeRequest(url):
    xbmc.log("makeRequest: " + url)

    try:
        req      = urllib2.Request(url)
        response = urllib2.urlopen(req)
        data     = response.read()
        response.close()
        return data
    except urllib2.URLError, e:
        errorMsg = str(e)
        xbmc.log(errorMsg);
        xbmc.executebuiltin("Notification(Flooxer,"+errorMsg+")")
        data_err = []
        data_err.append(['error', True])
        data_err.append(['msg', errorMsg])
        data_err = json.dumps(data_err)
        data_err = "{\"error\":\"true\", \"msg\":\""+errorMsg+"\"}"
        return data_err

# Comprobar si la cadena es json
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError, e:
        return False
    return True


# Mostrar errores
def mostrar_errores(titulo, mensaje, debug=""):
    xbmc.log("ERROR: " + titulo)

    listing = []
    errTitle = "[COLOR red][UPPERCASE]" + titulo + "[/UPPERCASE][/COLOR]"
    errMsg = mensaje + "[CR]Para mas informacion, por favor, consulta el registro."

    list_item = xbmcgui.ListItem(label=errTitle, iconImage='DefaultFolder.png')
    url = '{0}'.format(_url)
    is_folder = True
    listing.append((url, list_item, is_folder))

    list_item = xbmcgui.ListItem(label=errMsg, iconImage='DefaultFolder.png')
    url = '{0}'.format(_url)
    is_folder = True
    listing.append((url, list_item, is_folder))

    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

    return


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])

# xbmcplugin.setContent(addon_handle, 'movies')

# list_categories()

# # Categoría Home
# url = build_url({'mode': 'folder', 'foldername': 'home'})
# li  = xbmcgui.ListItem('Home', iconImage='DefaultFolder.png')
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

# # Categoría Original
# url = build_url({'mode': 'folder', 'foldername': 'home'})
# li  = xbmcgui.ListItem('Original', iconImage='DefaultFolder.png')
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

# # Categoría Primero aqui
# url = build_url({'mode': 'folder', 'foldername': 'primero-aqui'})
# li  = xbmcgui.ListItem('Primero aqui', iconImage='DefaultFolder.png')
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

# # Categoría Populares
# url = build_url({'mode': 'folder', 'foldername': 'videos'})
# li  = xbmcgui.ListItem('Populares', iconImage='DefaultFolder.png')
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

# # Categoría Últimos
# url = build_url({'mode': 'folder', 'foldername': 'ultimos-videos'})
# li  = xbmcgui.ListItem('Últimos', iconImage='DefaultFolder.png')
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)


# label     = '¿Qué pasa cuando miramos más allá de nuestro horizonte? | Astral'
# url       = 'http://despro.flooxer.com/assets14/2016/09/21/DB836319-E168-4EB7-B963-9291B513ADAE/video_480p_930k_es.mp4'
# fanart    = 'https://image.flooxer.com//clipping/cmsimages02//2016/09/21/DCF46B7F-DA98-408B-B03C-0208F764B0F0/54.jpg'
# thumbnail = 'https://image.flooxer.com//clipping/cmsimages02//2016/09/21/DCF46B7F-DA98-408B-B03C-0208F764B0F0/52.jpg'

# li = xbmcgui.ListItem(label, thumbnail)
# li.setIconImage('icon.png')
# li.setArt({'thumb': thumbnail, 'icon': thumbnail, 'fanart': fanart})
# info = {'genre': 'Horror', 'year': 1979, 'title': 'Alien',}
# li.setInfo('video', info)
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

# label     = 'Entertainment 2x09 Sumisión'
# url       = 'http://despro.flooxer.com/assets13/2016/09/21/C42E396A-C468-444B-B321-8A0C00FEDE3A/video_480p_930k_es.mp4'
# thumbnail = 'https://image.flooxer.com//clipping/cmsimages02//2016/09/21/319F9513-9AD4-44E6-AC0D-C54128EBFA67/52.jpg'
# li = xbmcgui.ListItem(label, thumbnail)
# li.setIconImage('icon.png')
# li.setArt({'thumb': thumbnail, 'icon': thumbnail, 'fanart': fanart})
# info = {'genre': 'Horror', 'year': 1979, 'title': 'Alien',}
# li.setInfo('video', info)
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

# label     = 'Cómo ser un genio de whatsapp'
# url       = 'http://despro.flooxer.com/assets14/2016/09/21/3E08441E-0B5F-46BE-9751-D0A07295DAAE/video_480p_930k_es.mp4'
# thumbnail = 'https://image.flooxer.com//clipping/cmsimages02//2016/09/21/3FB06C17-6A42-4C7B-82C2-A6EC6EA826B5/52.jpg'
# li = xbmcgui.ListItem(label, thumbnail)
# li.setIconImage('icon.png')
# li.setArt({'thumb': thumbnail, 'icon': thumbnail, 'fanart': fanart})
# info = {'genre': 'Horror', 'year': 1979, 'title': 'Alien',}
# li.setInfo('video', info)
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

# xbmcplugin.endOfDirectory(addon_handle)
