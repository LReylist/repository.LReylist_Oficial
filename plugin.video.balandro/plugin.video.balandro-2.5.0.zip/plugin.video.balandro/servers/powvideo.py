# -*- coding: utf-8 -*-

import re
import base64
import urllib

from core import httptools
from core import scrapertools
from lib import jsunpack, balandroresolver
from platformcode import logger


def test_video_exists(page_url):
    page_url = page_url.replace('embed-', 'iframe-').replace('preview-', 'iframe-')
    referer = page_url.replace('iframe', 'preview')
    data = httptools.downloadpage(page_url, headers={'referer': referer}).data
    if data == "File was deleted" or data == '':
        return False, "[powvideo] El video ha sido borrado"
    if 'function(p,a,c,k,e,' not in data:
        return False, "[powvideo] El video no está disponible"
    return True, ""


def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    logger.info()
    itemlist = []

    page_url = page_url.replace('embed-', 'iframe-').replace('preview-', 'iframe-')

    referer = page_url.replace('iframe', 'preview')

    data = httptools.downloadpage(page_url, headers={'referer': referer}).data

    packed = scrapertools.find_single_match(data, "<script type=[\"']text/javascript[\"']>(eval.*?)</script>")
    if packed == '':
        packed = scrapertools.find_single_match(data, "(eval.*?)</script>")
    unpacked = jsunpack.unpack(packed)
    # ~ logger.debug(unpacked)
    
    url = scrapertools.find_single_match(unpacked, "(?:src):\\\\'([^\\\\]+.mp4)\\\\'")
    # ~ logger.debug(url)

    itemlist.append([".mp4" + " [powvideo]", balandroresolver.decode_video_url(url, data)])

    itemlist.sort(key=lambda x: x[0], reverse=True)
    return itemlist
