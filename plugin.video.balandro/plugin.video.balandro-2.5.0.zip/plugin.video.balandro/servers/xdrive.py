# -*- coding: utf-8 -*-

from core import httptools
from core import scrapertools
from platformcode import config, logger


def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)

    data = httptools.downloadpage(page_url).data
    if 'This file has been Removed' in data:
        return False, '[Xdrive] El archivo no existe o ha sido borrado'

    return True, ""


def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    logger.info("(page_url='%s')" % page_url)
    video_urls = []

    data = httptools.downloadpage(page_url).data
    # ~ logger.debug(data)
    
    video_id = scrapertools.find_single_match(data, "&video_id=([^']+)")

    ipdata = httptools.downloadpage('https://xdrive.cc/geo_ip').data
    ip = scrapertools.find_single_match(ipdata, '"ip":"([^"]+)')
    
    headers = {'Referer': page_url}
    sources = httptools.downloadpage('https://xdrive.cc/secure_link?ip=%s&video_id=%s' % (ip, video_id), headers=headers).data
    # ~ logger.debug(sources)
    
    # ~ urls = scrapertools.find_multiple_matches(sources.replace('\\/', '/'), '"([^"]+)"')
    # ~ if len(urls) == 3:
        # ~ video_urls.append(['HD [Xdrive]', urls[0]])
        # ~ video_urls.append(['SD [Xdrive]', urls[1]])
        # ~ if urls[2] != urls[1]:
            # ~ video_urls.append(['SD min [Xdrive]', urls[2]])
    # ~ else:
        # ~ for url in urls:
            # ~ video_urls.append(['mp4 [Xdrive]', url])

    url = scrapertools.find_single_match(sources.replace('\\/', '/'), '"([^"]+)"')
    if url != '':
        video_urls.append(['HD [Xdrive]', url])

    return video_urls
