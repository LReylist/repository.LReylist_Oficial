# -*- coding: utf-8 -*-

import re

from core import httptools
from core import scrapertools
from core import servertools
from core import tmdb
from core.item import Item
from platformcode import config, logger

host = 'http://seriesblanco.org/'


def mainlist(item):
    return mainlist_series(item)

def mainlist_series(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title='Todas por orden alfabético', action='list_all', url=host+'lista-de-series/' ))
    itemlist.append(item.clone( title='Por género', action='section', url=host ))
    itemlist.append(item.clone( title='Por letra (A - Z)', action='section', url=host+'lista-de-series/' ))

    itemlist.append(item.clone( title='Nuevos capítulos', action='new_episodes', url=host ))

    itemlist.append(item.clone( title = 'Buscar', action = 'search' ))

    return itemlist


def get_source(url):
    data = httptools.downloadpage(url).data
    data = re.sub(r'\n|\r|\t|&nbsp;|<br>|\s{2,}', "", data)
    return data

def list_all(item):
    logger.info()
    itemlist = []

    data = get_source(item.url)
    patron = '<div style="float.*?<a href="([^"]+)">.*?src="([^"]+)".*?data-original-title="([^"]+)">'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, scrapedthumbnail, scrapedtitle in matches:
        title = scrapertools.decodeHtmlentities(scrapedtitle)
        itemlist.append(Item(channel=item.channel,
                             action='seasons',
                             title=title,
                             url=scrapedurl,
                             thumbnail=scrapedthumbnail,
                             contentType='tvshow',
                             contentSerieName=scrapedtitle
                             ))

    tmdb.set_infoLabels_itemlist(itemlist, seekTmdb=True)

    # #Paginacion
    if len(itemlist) > 0:
        next_page = scrapertools.find_single_match(data, '<a class="next page-numbers" href="([^"]+)">')
        if next_page != '':
            itemlist.append(item.clone(title='Página siguiente >>', url=next_page) )

    return itemlist


def section(item):
    logger.info()
    itemlist = []

    data = get_source(item.url)
    if item.url == host: # 'Por Género'
        patron = '<li><a href="([^"]+)"><i class="fa fa-bookmark-o"></i> ([^<]+)</a></li>'
    else: # 'A - Z'
        patron = '<a dir="ltr" href="([^"]+)" class="label label-primary">([^<]+)</a>'

    matches = re.compile(patron, re.DOTALL).findall(data)
    for scrapedurl, scrapedtitle in matches:
        itemlist.append(item.clone(action='list_all', title=scrapedtitle, url=scrapedurl) )

    return itemlist


def seasons(item):
    logger.info()
    itemlist = []
    
    data = get_source(item.url)

    if item.contentSerieName == '': # Si viene de new_episodes no está establecida la serie 
        item.contentSerieName = scrapertools.find_single_match(data, 'Título original:</font></b>([^<]+)').strip()

    patron = '<span itemprop="seasonNumber" class="fa fa-arrow-down">.*?Temporada (\d+) '
    matches = re.compile(patron, re.DOTALL).findall(data)
    for scrapedseason in matches:
        title = 'Temporada %s' % scrapedseason
        itemlist.append(item.clone(action='episodesxseason', title=title, contentType='season', contentSeason=scrapedseason) )

    tmdb.set_infoLabels_itemlist(itemlist, seekTmdb=True)

    return itemlist


def episodios(item):
    logger.info()
    itemlist = []
    templist = seasons(item)
    for tempitem in templist:
        itemlist += episodesxseason(tempitem)
    return itemlist


def episodesxseason(item):
    logger.info()
    itemlist = []

    data = get_source(item.url)

    if item.contentSerieName == '': # Si viene de new_episodes no está establecida la serie 
        item.contentSerieName = scrapertools.find_single_match(data, 'Título original:</font></b>([^<]+)').strip()

    season_data = scrapertools.find_single_match(data, '<div id="collapse%s".*?</tbody>' % item.contentSeason)
    patron = '<td><a href="([^ ]+)".*?itemprop="episodeNumber">%sx(\d+)</span> (.*?) </a>.*?<td>(.*?)</td>' % item.contentSeason
    matches = re.compile(patron, re.DOTALL).findall(season_data)

    for scrapedurl, scraped_episode, scrapedtitle, lang_data in matches:
        title = '%sx%s - %s' % (item.contentSeason, scraped_episode, scrapedtitle.strip())
        title, language = add_language(title, lang_data)
        itemlist.append(item.clone(action='findvideos', url=scrapedurl, title=title, 
                                   contentType='episode', contentEpisodeNumber=scraped_episode, language=language) )

    tmdb.set_infoLabels_itemlist(itemlist, seekTmdb=True)

    return itemlist


def new_episodes(item):
    logger.info()
    itemlist = []

    data = get_source(item.url)
    data = scrapertools.find_single_match(data,
                                          '<center>Series Online : Capítulos estrenados recientemente</center>.*?</ul>')
    patron = '<li><h6.*?src="([^"]+)".*?alt=" (\d+x\d+).+?".*?href="([^"]+)">.*?src="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for lang_data, scrapedinfo, scrapedurl, scrapedthumbnail in matches:
        url = scrapedurl
        thumbnail = scrapedthumbnail
        scrapedinfo = scrapedinfo.split('x')
        season = scrapedinfo[0]
        episode = scrapedinfo[1]
        scrapedtitle = scrapertools.find_single_match(url, 'capitulo/([^/]+)/')
        url = '%scapitulos/%s' % (host, scrapedtitle)
        seriename = scrapedtitle.replace('-', ' ').capitalize()
        title = '%s - %sx%s' % (seriename, season, episode )
        title, language = add_language(title, lang_data)
        # ~ itemlist.append(Item(channel=item.channel,
                             # ~ action='seasons',
                             # ~ title=title,
                             # ~ url=url,
                             # ~ thumbnail=thumbnail,
                             # ~ language=language,
                             # ~ contentType='show', contentSerieName=seriename
                             # ~ ))
        itemlist.append(Item(channel=item.channel,
                             action='episodesxseason',
                             title=title,
                             url=url,
                             thumbnail=thumbnail,
                             language=language,
                             contentType='season', contentSerieName=seriename, contentSeason=season
                             ))

    # ~ tmdb.set_infoLabels_itemlist(itemlist, seekTmdb=True) # Como el nombre de la serie se obtiene de una url no es muy preciso, mejor que se obtenga en seasons/episodesxseason

    return itemlist

def add_language(title, string):
    IDIOMAS = {'es': 'Esp', 'la': 'Lat', 'vos': 'VOSE', 'vo': 'VO'}

    languages = scrapertools.find_multiple_matches(string, '/language/(.*?).png')
    language = []
    for lang in languages:
        if 'jap' in lang or lang not in IDIOMAS:
            lang = 'vos'

        if len(languages) == 1:
            language = IDIOMAS[lang]
            title = '%s [%s]' % (title, language)
        else:
            language.append(IDIOMAS[lang])
            title = '%s [%s]' % (title, IDIOMAS[lang])

    return title, language


def findvideos(item):
    logger.info()
    itemlist = []

    data = get_source(item.url)
    patron = '<imgsrc="([^"]+)".*?<a class="open-link" data-enlace="([^"]+)".*?<td>([^<]+)</td>'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for lang_data, scrapedurl, quality in matches:
        title = '%s'
        if quality == '': quality = 'SD'
        title = '%s [%s]' % (title, quality)
        title, language = add_language(title, lang_data)
        url = scrapedurl
        if 'streamcrypt' in url:
            url = url.replace('https://streamcrypt', 'https://www.streamcrypt')
            temp_data = httptools.downloadpage(url, follow_redirects=False, only_headers=True)
            if 'location' in temp_data.headers:
                url = temp_data.headers['location']
            else:
                continue

        itemlist.append(Item(channel = item.channel, action = 'play',
                             title = title, url = url,
                             language = language, quality = quality
                       ))

    itemlist = servertools.get_servers_itemlist(itemlist)

    return sorted(itemlist, key=lambda it: it.language)


def search(item, texto):
    logger.info()
    texto = texto.replace(" ", "+")
    item.url = host + "?s=" + texto

    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    try:
        return list_all(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
