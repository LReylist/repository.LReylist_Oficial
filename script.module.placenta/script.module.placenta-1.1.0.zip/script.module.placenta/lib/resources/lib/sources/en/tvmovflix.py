# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @tantrumdev wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Placenta
# Addon id: plugin.video.placenta
# Addon Provider: MuadDib

import re, urlparse, urllib, base64

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import cfscrape

User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['tvmovieflix.com']
        self.base_link = 'http://tvmovieflix.com/'
        self.search_link = '%s/index.php?menu=search&query=%s'
        self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            search_id = title.lower().replace(':', ' ').replace('-', ' ')
            start_url = self.search_link % (self.base_link, search_id.replace(' ','+'))

            headers={'User-Agent':User_Agent}
            html = self.scraper.get(start_url,headers=headers,timeout=10).content
            match = re.compile('class="item".+?href="(.+?)".+?<h2>(.+?)</h2>.+?class="year">(.+?)</span>',re.DOTALL).findall(html)
            for url,name,date in match:
                if search_id == name.lower().replace(':', ' ').replace('-', ' '):
                    if year in date:
                        sources = get_source(url, sources)
            return sources
        except:
            pass
            return[]

    def get_source(self,url,sources):
        try:
            headers={'User-Agent':User_Agent}
            OPEN = self.scraper.get(url,headers=headers,timeout=10).content
            Regex = re.compile('href="(http://tvmovieflix.com/m/.+?)" rel="nofollow"',re.DOTALL).findall(OPEN)
            for link in Regex:
                holder = self.scraper.get(link).content  
                vid = re.compile('<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',re.DOTALL).findall(holder)
                for end_url in vid:
                    if 'realtalksociety' in end_url:
                        new = self.scraper.get(end_url).content 
                        get = re.compile('source src="(.+?)"',re.DOTALL).findall(new)
                        for play in get:
                            sources.append({'source': 'DirectLink', 'quality': '720p', 'language': 'en', 'url': play,'info': info, 'direct': True, 'debridonly': False})
                    else:
                        host = end_url.split('//')[1].replace('www.','')
                        host = host.split('/')[0].split('.')[0].title()
                        sources.append({'source': host, 'quality': 'SD', 'language': 'en', 'url': end_url,'info': info, 'direct': False, 'debridonly': False})
            return sources
        except:
            return sources
            pass

    def resolve(self, url):
        if self.base_link in url:
            url = client.request(url)
            url = client.parseDOM(url, 'div', attrs={'class': 'wrap'})
            url = client.parseDOM(url, 'a', ret='href')[0]
        return url

                                           
class tvmovflix(Scraper):


    def scrape_movie(self, title, year, imdb, debrid = False):
        try:
            search_id = clean_search(title.lower())
            start_url = self.base_link + '/index.php?menu=search&query=' + search_id.replace(' ','+')
            #print 'GW> '+start_url
            headers={'User-Agent':User_Agent}
            html = self.scraper.get(start_url,headers=headers,timeout=10).content
            match = re.compile('class="item".+?href="(.+?)".+?<h2>(.+?)</h2>.+?class="year">(.+?)</span>',re.DOTALL).findall(html)
            for url,name,date in match:
                #print '%s  %s  %s'  %(url,name,date)
                if clean_title(title).lower() == clean_title(name).lower():
                    if year in date:
                        #print 'moviflix CHK Movie> ' + url
                        self.get_source(url)
            
            return self.sources
        except:
            pass
            return[]

    def scrape_episode(self, title, show_year, year, season, episode, imdb, tvdb, debrid = False):
        try:
            search_id = clean_search(title.lower().replace(' ','-'))
            episode_url = '%s/show/%s/season/%s/episode/%s' % (self.base_link,search_id,season,episode)
            
            #print 'moviflix CHECK TV URL ' + episode_url
            url = episode_url
            self.get_source(url)

            return self.sources
        except Exception, argument:
            return self.sources  
            


