# coding: utf-8
# Main Addon
__author__ = 'mancuniancol'

from xbmcswift2 import Plugin
from tools2 import *

##INITIALISATION
storage = Storage(settings.storageName, type="dict")
plugin = Plugin()


###############################
###  MENU    ##################
###############################
@plugin.route('/')
def index():
    textViewer(settings.string(32000), once=True)
    items = [
        {'label': "Busqueda Manual",
         'path': plugin.url_for('search'),
         'thumbnail': dirImages("busqueda-manual.png"),
         'properties': {'fanart_image': settings.fanart}
         }]
    listTypes = ['Series Más Vistas',
                 'Series Más recientes',
                 'Series Más Populares',
                 'Animes',
                 'Novelas',
                 ]
    listType2 = ['series',
                 'series',
                 'series',
                 'generos',
                 'generos',
                 ]
    listOrder = ['hits',
                 'fecha',
                 'rating',
                 'animes',
                 'novelas',
                 ]
    listIcons = [dirImages("series.png"),
                 dirImages("series.png"),
                 dirImages("estrenos.png"),
                 dirImages("series.png"),
                 dirImages("series.png"),
                 ]
    for type, type2, order, icon in zip(listTypes, listType2, listOrder, listIcons):
        items.append({'label': type,
                      'path': plugin.url_for('readItems', type2=type2, order=order),
                      'thumbnail': icon,
                      'properties': {'fanart_image': settings.fanart},
                      })
    items.append({'label': "Ayuda",
                  'path': plugin.url_for('help'),
                  'thumbnail': dirImages("ayuda.png"),
                  'properties': {'fanart_image': settings.fanart}
                  })
    return items


@plugin.route('/help/')
def help():
    textViewer(plugin.get_string(32000), once=False)


@plugin.route('/search/')
def search():
    query = settings.dialog.input("Cual película buscar?")
    url = "/busqueda/%s/pag:" % query
    return readItems(type2='search', order=query)


@plugin.route('/play/<url>')
def play(url):
    uri_string = quote_plus(url)
    # Set-up the plugin
    channel = "seriesflv"
    link = "plugin://plugin.video.pelisalacarta/?channel=%s&action=play_from_library&url=%s" % (channel, uri_string)
    # play media
    settings.debug("PlayMedia(%s)" % link)
    xbmc.executebuiltin("PlayMedia(%s)" % link)
    xbmc.executebuiltin('Dialog.Close(all, true)')


@plugin.route('/importOne/<title>')
def importOne(title=""):
    information = plugin.get_storage('information')
    title = normalize(title)
    info = information[title]
    integration(titles=[info.title], magnets=[info.fileName], id=[info.id], typeVideo=[info.typeVideo],
                channel="seriesflv", silence=True)


@plugin.route('/unsubscribe/<key>')
def unsubscribe(key=""):
    storage.remove(key)
    storage.save()


@plugin.route('/subscribe/<key>/<type2>/<order>')
def subscribe(key="", type2="", order=""):
    storage.add(key, (type2, order))
    storage.save()
    importAll(key, type2, order)


@plugin.route('/importAll/<key>/<type2>/<order>')
def importAll(key="", type2="", order=""):
    items = readItems(type2=type2, order=order)  # only to create information
    information = plugin.get_storage('information')
    titles = []
    magnets = []
    typeVideo = []
    id = []
    # read information from Storage
    for key in information:
        titles.append(information[key].title)
        magnets.append(information[key].fileName)
        typeVideo.append(information[key].typeVideo)
        id.append(information[key].id)
    integration(titles=titles, magnets=magnets, id=id, typeVideo=typeVideo, channel="seriesflv", silence=True)


@plugin.route('/readItems/<type2>/<order>', name="readItems")
@plugin.route('/nextPage/<type2>/<order>/<page>', name="nextPage")
def readItems(type2="", order="", page="1"):
    # read from URL
    if type2 == "search":
        url = settings.value["urlAddress"] + '/api/search/?q=%s' % order
        parameters = ""
    else:
        url = settings.value["urlAddress"] + '/ajax/lista.php'
        parameters = {'grupo_no': page, 'type': type2, 'order': order}
    settings.log(url)
    response = browser.post(url=url, data=parameters)
    soup = bs4.BeautifulSoup(response.text)
    links = soup.select("a")

    # Storage information
    information = plugin.get_storage('information')
    information.clear()
    information.sync()

    # Items Menu Creation
    items = []
    typeVideo = ""
    for a in links:
        if parameters == "":
            title = a.span.text
        else:
            title = a.div.text.strip()
        urlSource = a["href"]
        info = UnTaggle(title, urlSource, "SHOW")  # it gets all the information from the title and url
        information[title] = info  # save for importAll
        try:
            title = normalize(title)
            if info.id in storage.database.keys():
                importInfo = (settings.string(32001),
                              'XBMC.Container.Update(%s)' % plugin.url_for('unsubscribe', key=title))
            else:
                importInfo = (settings.string(32002),
                              'XBMC.Container.Update(%s)' % plugin.url_for('subscribe', key=title, type2=type2,
                                                                           order=order))

            items.append({'label': info.label,
                          'path': plugin.url_for('seasons', url=urlSource, thumbnail=info.cover,
                                                 fanart=info.fanart),
                          'thumbnail': info.cover,
                          'properties': {'fanart_image': info.fanart},
                          'info': info.infoLabels,
                          'context_menu': [importInfo, (plugin.get_string(32009),
                                                        'XBMC.RunPlugin(%s)' % plugin.url_for('importAll', key=title,
                                                                                              type2=type2,
                                                                                              order=order))]
                          })
        except:
            pass
    information.sync()

    # SetContent
    typeVideo = "tvshows"
    # main
    if __name__ == '__main__':
        plugin.set_content(typeVideo)

    # next page
    items.append({'label': "Página Siguiente..",
                  'path': plugin.url_for('nextPage', type2=type2, order=order, page=int(page) + 1),
                  'thumbnail': settings.icon,
                  'properties': {'fanart_image': settings.fanart}
                  })
    return plugin.finish(items=items, view_mode=settings.value['viewMode'])


@plugin.route('/seasons/<url>/<thumbnail>/<fanart>')
def seasons(url, thumbnail, fanart=settings.fanart):
    urlDict = plugin.get_storage('urlDict')
    urlDict.clear()
    urlDict.sync()
    titleDict = plugin.get_storage('titleDict')
    titleDict.clear()
    titleDict.sync()
    response = browser.get(url)  # open the serie
    if response.status_code == requests.codes.ok:
        soup = bs4.BeautifulSoup(response.text)
        infoTitle = ''
        if soup.select('tr.mainInfoClass a')[0].text:
            links = soup.select('td.sape a')
            for link in links:
                infoTitle = formatTitle(link.text, typeVideo="SHOW")
                season = infoTitle.get("season", 0)
                if titleDict.get(season, "") == "":
                    titleDict[season] = []
                titleDict[season].append(infoTitle)
                if urlDict.get(season, "") == "":
                    urlDict[season] = []
                urlDict[season].append(link.attrs.get('href'))
        # creating season items
        items = []
        infoLabels = getInfoLabels(infoTitle)  # using script.module.metahandlers to the the infoLabels
        settings.debug(infoTitle)
        settings.debug(infoLabels)
        infoSeason = getInfoSeason(infoLabels, titleDict.keys())
        settings.debug(infoSeason)
        for season, images in zip(titleDict.keys(), infoSeason):
            items.append({'label': "Temporada %s" % season,
                          'path': plugin.url_for('episodes', season=season),
                          'thumbnail': images["cover_url"],
                          'properties': {'fanart_image': images["backdrop_url"]},
                          'info': infoLabels,
                          })
        # SetContent
        typeVideo = "tvshows"
        # main
        if __name__ == '__main__':
            plugin.set_content(typeVideo)
        return plugin.finish(items=items, view_mode=settings.value['viewMode'])
    else:
        settings.log(">>>>>>>HTTP %s<<<<<<<" % response.status_code)
        settings.notification(message="HTTP %s" % response.status_code, force=True)


@plugin.route('/episodes/<season>')
def episodes(season="0"):
    urlDict = plugin.get_storage('urlDict')
    titleDict = plugin.get_storage('titleDict')
    items = []
    season = int(season)
    for urlSource, infoTitle in zip(urlDict[season], titleDict[season]):
        infoLabels = getInfoLabels(infoTitle)  # using script.module.metahandlers to the the infoLabels
        infoStream = getInfoStream(infoTitle, infoLabels)
        infoEpisode = getInfoEpisode(infoLabels)
        settings.debug(infoTitle)
        settings.debug(infoLabels)
        settings.debug(infoStream)
        settings.debug(infoEpisode)
        items.append({'label': "%02d. %s" % (infoEpisode['episode'], infoEpisode['title']),
                      'path': plugin.url_for('play', url=urlSource),
                      'thumbnail': infoEpisode["cover_url"],
                      'properties': {'fanart_image': infoEpisode["backdrop_url"]},
                      'info': infoEpisode,
                      'stream_info': infoStream,
                      'context_menu': [
                          (plugin.get_string(32009),
                           'XBMC.RunPlugin(%s)' % plugin.url_for('importOne', title=infoTitle["title"]))
                      ]
                      })
    # SetContent
    typeVideo = "episodes"
    # main
    if __name__ == '__main__':
        plugin.set_content(typeVideo)
    return plugin.finish(items=items, view_mode=settings.value['viewMode'])


# parsing HTML


# main
if __name__ == '__main__':
    plugin.run()
